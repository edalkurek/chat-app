package com.ykt.chatapp.confluence;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.nodes.Node;
import org.jsoup.nodes.TextNode;
import org.jsoup.parser.Parser;
import org.jsoup.select.NodeTraversor;
import org.jsoup.select.NodeVisitor;

/**
 * Confluence "storage" formatını (XHTML + ac:/ri: makroları) LLM'e uygun, yapısı korunmuş düz metne çevirir.
 * Başlıklar "#", listeler "-", tablo hücreleri "|" ile işaretlenir; kod makrolarının içeriği korunur.
 */
final class StorageFormatConverter {

	private StorageFormatConverter() {
	}

	static String toText(String storage) {
		if (storage == null || storage.isBlank()) {
			return "";
		}
		Document doc = Jsoup.parse("<root>" + storage + "</root>", "", Parser.xmlParser());
		// Görsel/ek referansları ve makro parametreleri (dil adı, tema vb.) içeriğe katkı sağlamaz.
		doc.select("ac|parameter, ac|image, ri|attachment, ri|url, ac|placeholder").remove();

		StringBuilder out = new StringBuilder();
		NodeTraversor.traverse(new NodeVisitor() {
			@Override
			public void head(Node node, int depth) {
				if (node instanceof TextNode text) {
					boolean pre = insidePre(text);
					out.append(pre ? text.getWholeText() : text.text());
					return;
				}
				if (!(node instanceof Element el)) {
					return;
				}
				switch (el.normalName()) {
					case "h1", "h2", "h3", "h4", "h5", "h6" -> {
						newline(out);
						out.append("#".repeat(el.normalName().charAt(1) - '0')).append(' ');
					}
					case "li" -> {
						newline(out);
						out.append("- ");
					}
					case "tr" -> newline(out);
					case "td", "th" -> out.append("| ");
					case "br" -> out.append('\n');
					case "p", "div", "table", "ul", "ol", "blockquote", "pre", "ac:structured-macro",
							"ac:plain-text-body", "ac:rich-text-body" -> newline(out);
					default -> {
					}
				}
			}

			@Override
			public void tail(Node node, int depth) {
				if (!(node instanceof Element el)) {
					return;
				}
				switch (el.normalName()) {
					case "td", "th" -> out.append(' ');
					case "h1", "h2", "h3", "h4", "h5", "h6", "p", "div", "table", "ul", "ol", "blockquote", "pre",
							"tr", "ac:structured-macro", "ac:plain-text-body" -> newline(out);
					default -> {
					}
				}
			}
		}, doc);

		return out.toString()
				.replace('\u00A0', ' ')
				.replaceAll("[ \\t]+\\n", "\n")
				.replaceAll("\\n{3,}", "\n\n")
				.trim();
	}

	private static boolean insidePre(TextNode text) {
		for (Node p = text.parent(); p != null; p = p.parent()) {
			if (p instanceof Element e && ("pre".equals(e.normalName()) || "ac:plain-text-body".equals(e.normalName()))) {
				return true;
			}
		}
		return false;
	}

	private static void newline(StringBuilder out) {
		if (out.length() > 0 && out.charAt(out.length() - 1) != '\n') {
			out.append('\n');
		}
	}
}
