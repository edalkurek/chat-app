const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { JSDOM, VirtualConsole } = require('jsdom');
const { IDBFactory, IDBKeyRange } = require('fake-indexeddb');

const html = fs.readFileSync(path.join(__dirname, '..', 'chat-app.html'), 'utf8');

test('browser dependencies are local and complete for the desktop package', () => {
  const vendorRefs = [...html.matchAll(/(?:src|href)="vendor\/([^"?#]+)"/g)].map(match => match[1]);
  const workerRef = /workerSrc\s*=\s*'vendor\/([^']+)'/.exec(html)?.[1];
  assert.equal(vendorRefs.length, 12);
  assert.equal(workerRef, 'pdf.worker.min.js');
  const documentHead = html.slice(0, html.indexOf('</head>'));
  assert.doesNotMatch(documentHead, /(?:src|href)="https?:\/\/(?:cdn\.|cdnjs\.|unpkg\.|jsdelivr\.)/i);
  for (const file of [...vendorRefs, workerRef]) {
    assert.ok(fs.existsSync(path.join(__dirname, '..', 'vendor', file)), `Eksik vendor dosyası: ${file}`);
  }
});

function setup(t, { markdown = false } = {}) {
  const dom = new JSDOM(html, {
    url: 'http://localhost/', runScripts: 'outside-only', virtualConsole: new VirtualConsole(),
  });
  t.after(() => dom.window.close());
  const w = dom.window;
  w.TextDecoder = TextDecoder;
  w.indexedDB = new IDBFactory();
  w.IDBKeyRange = IDBKeyRange;
  w.fetch = async () => { throw new Error('Unexpected API call'); };
  if (markdown) {
    // Exercise the same browser builds as the page, including the real sanitizer.
    w.eval(fs.readFileSync(path.join(path.dirname(require.resolve('marked')), 'marked.umd.js'), 'utf8'));
    w.DOMPurify = require('dompurify')(w);
    w.hljs = require('highlight.js').newInstance();
    for (const language of ['java', 'javascript', 'xml', 'json', 'plaintext']) {
      w.hljs.registerLanguage(language, require(`highlight.js/lib/languages/${language}`));
    }
  }
  const script = [...w.document.scripts].find(s => s.textContent.includes('async function summarizeConversation()')).textContent;
  // Parse the complete production script, then load its functions without startup integrations.
  new (require('node:vm').Script)(script);
  w.eval(script.slice(0, script.lastIndexOf('(function init()')) + `
    apiConfig = { url: 'http://localhost/v1/chat/completions', method: 'POST', headers: {'Content-Type': 'application/json'},
      bodyTemplate: '{"messages":[{"role":"user","content":"$PROMPT"}],"model":"test"}',
      responsePath: 'choices.0.message.content' };
    window.app = {
      summarizeConversation, sendMessage, generateAssistantReply, callApi, callApiStreaming,
      stopGeneration, renderMessages, renderContent, decorateCodeBlocks, buildMessageNode,
      beginEditMessage, cancelEditMode, saveHistory, loadHistory, startNewConversation, switchConversation,
      fillSettingsForm, downloadClone, importSettings, exportSettings, autoTagConversation, showUsageStats,
      getApiMessageContent, getMessageAttachments, loadPromptTemplates, loadCustomModels, rankKeywordChunks,
      searchRAG, indexDocument, openRAGDB, isRAGIndexing, loadConfig, saveConfigToLS,
      get history() { return chatHistory; }, set history(value) { chatHistory = value; },
      set streaming(value) { streamingEnabled = value; },
      get files() { return attachedFiles; }, set files(value) { attachedFiles = value; },
      set rag(value) { ragEnabled = value; },
      set augment(value) { augmentWithRAG = value; },
      get conversations() { return conversations; }, get activeId() { return activeConversationId; },
      get historyKey() { return LS_HISTORY_KEY; }, get conversationsKey() { return LS_CONVERSATIONS_KEY; },
      get settings() { return { apiConfig, customModels, promptTemplates, systemPrompt, streamingEnabled, ragEnabled }; },
      get config() { return apiConfig; }, get busy() { return isBusy; },
      get controller() { return activeRequestController; },
      get savedHistory() { return JSON.parse(localStorage.getItem(LS_CONVERSATIONS_KEY)).find(c => c.id === activeConversationId).messages; },
      get stopped() { return requestStoppedByUser; },
      confluenceRequest, renderConfluenceStatus, previewConfluencePage, publishConfluencePage,
      get confluenceStatus() { return confluenceStatus; },
      set confluenceStatus(value) { confluenceStatus = value; }
    };
  `);
  return { w, app: w.app };
}

test('Confluence mutation uses the local request guard and does not persist PAT in browser storage', async t => {
  const { w, app } = setup(t);
  let request;
  w.fetch = async (path, options) => {
    request = { path, options };
    return new Response(JSON.stringify({ tokenConfigured: true }), {
      headers: { 'content-type': 'application/json' },
    });
  };
  await app.confluenceRequest('/api/confluence-token', {
    method: 'PUT', body: JSON.stringify({ pat: 'private-pat' }),
  });
  assert.equal(request.path, '/api/confluence-token');
  assert.equal(request.options.headers['X-ChatApp-Request'], '1');
  assert.equal(request.options.headers['Content-Type'], 'application/json');
  assert.doesNotMatch(JSON.stringify(w.localStorage), /private-pat/);
});

test('Confluence tools remain disabled until a PAT is configured', t => {
  const { w, app } = setup(t);
  const toggle = w.document.getElementById('confluenceRagToggle');
  const editor = w.document.getElementById('confluenceEditorOpenBtn');
  app.confluenceStatus = { baseUrl: 'https://example.test/confluence', tokenConfigured: false };
  app.renderConfluenceStatus();
  assert.equal(toggle.disabled, true);
  assert.equal(editor.disabled, true);
  app.confluenceStatus = { baseUrl: 'https://example.test/confluence', tokenConfigured: true };
  app.renderConfluenceStatus();
  assert.equal(toggle.disabled, false);
  assert.equal(editor.disabled, false);
});

test('Confluence publishing requires a current preview and escapes new-page content', async t => {
  const { w, app } = setup(t);
  w.document.getElementById('confluenceSpaceKey').value = 'KRD';
  w.document.getElementById('confluencePageTitle').value = 'Title';
  w.document.getElementById('confluencePageBody').value = '<script>alert(1)</script>';
  app.previewConfluencePage();
  assert.equal(w.document.getElementById('confluencePublishBtn').disabled, false);
  assert.equal(w.document.getElementById('confluencePreviewBody').querySelector('script'), null);
  w.document.getElementById('confluencePageBody').value = 'Changed';
  await app.publishConfluencePage();
  assert.equal(w.document.getElementById('confluencePublishBtn').disabled, true);
  assert.match(w.document.getElementById('confluenceEditorStatus').textContent, /tekrar/);
});

function jsonReply(content) {
  return new Response(JSON.stringify({ choices: [{ message: { content } }], usage: { prompt_tokens: 10, completion_tokens: 5, total_tokens: 15 } }),
    { headers: { 'content-type': 'application/json' } });
}
function event(content, finish_reason = null) {
  return 'data: ' + JSON.stringify({ choices: [{ delta: { content }, finish_reason }] }) + '\r\n\r\n';
}

const javaMethod = [
  '@RequestMapping("/detail/downloadPdf.do")',
  'public void detailDownloadPdf(HttpServletRequest request, HttpServletResponse response) throws Exception {',
  '\tUserContextDTO userContext = UserSession.getUserContext(request);  ',
  '\tList<FilePackageDetail> details = getFromScope("previousFileDetailList");',
  '',
  '\tif (details != null && !details.isEmpty()) {',
  '\t\tString html = "<section data-key=\\"x\\">&lt; &amp; **literal** `tick`</section>";',
  '\t\tdocResponse.write(details, response);',
  '\t}',
  '}',
  '',
].join('\n');

function codeTexts(node) {
  return [...node.querySelectorAll('pre code')].map(code => code.textContent);
}

function captureClipboard(w) {
  const copied = [];
  Object.defineProperty(w.navigator, 'clipboard', { configurable: true, value: {
    writeText: async text => { copied.push(text); },
  } });
  return copied;
}

for (const role of ['user', 'assistant']) {
  test(`${role} unfenced Java method stays one highlighted block with exact whitespace`, t => {
    const { app } = setup(t, { markdown: true });
    const node = app.buildMessageNode({ role, content: javaMethod }, 0);
    assert.deepEqual(codeTexts(node), [javaMethod]);
    assert.equal(node.querySelectorAll('.code-block-wrapper').length, 1);
    assert.equal(node.querySelectorAll('.msg-content ul, .msg-content li').length, 0);
    assert.ok(node.querySelector('pre code .hljs-keyword'), 'real Java syntax highlighting runs');
    assert.equal(node.querySelector('pre code section'), null, 'HTML-like code remains literal text');
    const pre = node.querySelector('pre');
    assert.equal(pre.querySelector('code').textContent.split('\n')[2].startsWith('\t'), true);
  });
}

test('prose and multiple fenced blocks remain separate with Markdown only outside code', t => {
  const { app } = setup(t, { markdown: true });
  const markup = '\t<section data-x="1">&lt; &amp; **literal** `tick`</section>  \n\n';
  const source = '**Önce Java:**\n\n```java\n' + javaMethod + '```\n\nArdından `HTML` örneği:\n\n~~~html\n' + markup + '~~~\n\nBitti.';
  const node = app.buildMessageNode({ role: 'assistant', content: source }, 0);
  assert.deepEqual(codeTexts(node), [javaMethod, markup]);
  assert.equal(node.querySelectorAll('.code-block-wrapper').length, 2);
  assert.equal(node.querySelector('strong').textContent, 'Önce Java:');
  assert.ok([...node.querySelectorAll('p')].some(p => p.textContent === 'Ardından HTML örneği:'));
  assert.ok([...node.querySelectorAll('p')].some(p => p.textContent === 'Bitti.'));
  assert.equal(node.querySelector('pre strong, pre section'), null);
});

for (const markdown of [false, true]) {
  test(`${markdown ? 'real Markdown' : 'offline fallback'} separates raw Java from following Turkish prose and another fence`, async t => {
    const { w, app } = setup(t, { markdown });
    const copied = captureClipboard(w);
    const second = '<div>Örnek &amp;</div>\n';
    const explanation = '**Bu metot dosyayı indirir.**';
    const source = javaMethod + '\n' + explanation + '\n\n```html\n' + second + '```\n\nİşlem tamamlandı.';
    const node = app.buildMessageNode({ role: 'assistant', content: source }, 0);
    assert.deepEqual(codeTexts(node), [javaMethod, second]);
    assert.equal(node.querySelector('strong').textContent, 'Bu metot dosyayı indirir.');
    assert.ok(node.querySelector('.msg-content').textContent.includes('İşlem tamamlandı.'));
    node.querySelector('.code-copy-btn[title="Kodu kopyala"]').click();
    await Promise.resolve();
    assert.deepEqual(copied, [javaMethod]);
  });
}

for (const [label, prefix] of [
  ['line comment', '// Download the document; a } in this comment is not a method boundary.\n'],
  ['Javadoc', '/**\n * Download {document}.\n * @return nothing\n */\n'],
  ['multiline annotation', '@RequestMapping(\n    value = "/detail/downloadPdf.do",\n    method = RequestMethod.GET\n)\n'],
  ['comments and multiline annotation', '/** Download the document. */\n// Keep the indentation.\n@RequestMapping(\n    value = "/detail/downloadPdf.do"\n)\n'],
]) {
  test(`raw Java declaration with leading ${label} stays one complete code block`, t => {
    const { app } = setup(t, { markdown: true });
    const source = prefix + 'public void run() {\n\tcall("<x>&");  \n}\n';
    const node = app.buildMessageNode({ role: 'user', content: source }, 0);
    assert.deepEqual(codeTexts(node), [source]);
    assert.equal(node.querySelectorAll('.code-block-wrapper').length, 1);
    assert.equal(node.querySelector('.msg-content li'), null);
  });
}

test('raw Java ignores braces inside strings, characters, comments and text blocks when finding its end', t => {
  const { app } = setup(t, { markdown: true });
  const source = [
    'public String example() {',
    '\tString quoted = "brace } and escaped quote \\" {";',
    '\tchar close = \'}\';',
    '\t// } another comment brace {',
    '\t/* } a block comment with { and another } */',
    '\tString text = """',
    '\t\t} **literal text** {',
    '\t\t<div>Not a method ending: }</div>',
    '\t\t""";',
    '\tif (quoted != null) {',
    '\t\treturn text;',
    '\t}',
    '\treturn "}";',
    '}',
    '',
  ].join('\n');
  const node = app.buildMessageNode({ role: 'assistant', content: source + '\n**Metot burada tamamlandı.**' }, 0);
  assert.deepEqual(codeTexts(node), [source]);
  assert.equal(node.querySelector('strong').textContent, 'Metot burada tamamlandı.');
  assert.equal(node.querySelector('pre strong, pre div'), null);
});

test('prose preceding an unfenced Java signature is not absorbed into a Java code block', t => {
  const { app } = setup(t, { markdown: true });
  const source = 'Bu metodu kullan\npublic void run() {\n    call();\n}\n';
  const node = app.buildMessageNode({ role: 'user', content: source }, 0);
  assert.ok([...node.querySelectorAll('.msg-content p')].some(p => p.textContent.includes('Bu metodu kullan')));
  assert.ok(codeTexts(node).every(code => !code.includes('Bu metodu kullan')));
});

test('long fences protect shorter fence text and unknown languages remain readable literal code', async t => {
  const { w, app } = setup(t, { markdown: true });
  const copied = captureClipboard(w);
  const payload = '\n\t**not bold** _not italic_ `not inline`  \n```java\n<tag>&lt; && </tag>\n```\n\n';
  const source = '````madeup-language\n' + payload + '````';
  const node = app.buildMessageNode({ role: 'assistant', content: source }, 0);
  assert.deepEqual(codeTexts(node), [payload]);
  assert.equal(node.querySelector('pre strong, pre em, pre tag'), null);
  node.querySelector('.code-copy-btn[title="Kodu kopyala"]').click();
  await Promise.resolve();
  assert.deepEqual(copied, [payload]);
});

test('code clipboard preserves CRLF, tabs, blank lines and trailing spaces exactly', async t => {
  const { w, app } = setup(t, { markdown: true });
  const copied = captureClipboard(w);
  const payload = '\r\n\tpublic void run() {  \r\n\t\tcall("<x>&lt; &&");\r\n\t}\r\n\r\n';
  const node = app.buildMessageNode({ role: 'assistant', content: '```java\r\n' + payload + '```\r\n' }, 0);
  assert.deepEqual(codeTexts(node), [payload]);
  node.querySelector('.code-copy-btn[title="Kodu kopyala"]').click();
  await Promise.resolve();
  assert.deepEqual(copied, [payload]);
});

test('message HTML is sanitized while dangerous-looking code remains complete and inert', t => {
  const { app } = setup(t, { markdown: true });
  const payload = '<script>alert("x")</script>\n<img src=x onerror="alert(1)">\n<a href="javascript:alert(2)">text</a>\n';
  const node = app.buildMessageNode({ role: 'assistant', content: '<img src=x onerror="alert(1)">\n\n```html\n' + payload + '```' }, 0);
  assert.deepEqual(codeTexts(node), [payload]);
  assert.equal(node.querySelector('script, [onerror], [href^="javascript:"]'), null);
  assert.equal(node.querySelector('pre img, pre a'), null);
});

test('ordinary prose and a Markdown list are not mistaken for unfenced Java', t => {
  const { app } = setup(t, { markdown: true });
  const content = 'Java metodunda şu adımları uygula:\n\n- Girdiyi kontrol et.\n- Sonucu döndür.\n\n`public void run()` imzasını kullan.';
  const node = app.buildMessageNode({ role: 'user', content }, 0);
  assert.deepEqual(codeTexts(node), []);
  assert.equal(node.querySelectorAll('li').length, 2);
  assert.equal(node.querySelector('p code').textContent, 'public void run()');
});

for (const markdown of [false, true]) {
  test(`${markdown ? 'real Markdown' : 'offline fallback'} preserves an open fence and literal code`, t => {
    const { app } = setup(t, { markdown });
    const payload = '\n\tList<String> values; // **keep** `keep` &lt; &&  \n\n';
    const node = app.buildMessageNode({ role: 'assistant', content: 'Açıklama\n\n~~~java\n' + payload }, 0);
    assert.deepEqual(codeTexts(node), [payload]);
    assert.equal(node.querySelector('pre strong, pre string'), null);
    assert.ok(node.querySelector('.msg-content').textContent.includes('Açıklama'));
  });
}

test('offline fallback keeps multiple fences separate and escapes code before inline Markdown', t => {
  const { app } = setup(t);
  const first = '\t**literal** <x>&amp;</x>  \n';
  const second = '\n```\n`literal`\n\n';
  const node = app.buildMessageNode({ role: 'assistant', content: 'Önce\n\n```java\n' + first + '```\n\nSonra\n\n````text\n' + second + '````' }, 0);
  assert.deepEqual(codeTexts(node), [first, second]);
  assert.equal(node.querySelector('pre strong, pre x'), null);
});

test('sending, editing, reloading, API history and message copy preserve original code source', async t => {
  const { w, app } = setup(t, { markdown: true });
  const copied = captureClipboard(w);
  const source = '\n\tpublic void run() {\n\t    call("<tag>&");\n\t}\n\n';
  const reply = '\n\n```java\n' + javaMethod + '```\n\n';
  const requests = [];
  w.fetch = async (_, options) => { requests.push(JSON.parse(options.body)); return jsonReply(reply); };
  w.document.getElementById('userInput').value = source;
  await app.sendMessage();
  assert.equal(app.history[0].content, source);
  assert.equal(app.history[0].apiContent, source);
  assert.equal(requests[0].messages[0].content, source);
  assert.equal(app.history[1].content, reply);
  assert.equal(app.savedHistory[0].content, source);
  app.loadHistory();
  assert.equal(app.history[0].content, source);
  app.beginEditMessage(0);
  assert.equal(w.document.getElementById('userInput').value, source);
  app.cancelEditMode(true);
  for (const [index, content] of [source, reply].entries()) {
    const node = app.buildMessageNode(app.history[index], index);
    const button = [...node.querySelectorAll('button')].find(btn => !btn.closest('.msg-content') && btn.textContent === 'Kopyala');
    assert.ok(button);
    button.click();
    await Promise.resolve();
    assert.equal(copied.at(-1), content);
  }
  w.document.getElementById('userInput').value = 'Devam';
  await app.sendMessage();
  assert.equal(requests[1].messages[0].content, source);
  assert.equal(requests[1].messages[1].content, reply);
});

test('whitespace-only drafts stay empty and attached-file defaults still apply', async t => {
  const { w, app } = setup(t);
  let calls = 0;
  w.fetch = async () => { calls++; return jsonReply('Yanıt'); };
  w.document.getElementById('userInput').value = ' \n\t\n ';
  await app.sendMessage();
  assert.equal(calls, 0);
  assert.equal(app.history.length, 0);
  app.files = [{ name: 'sample.txt', content: 'File text' }];
  await app.sendMessage();
  assert.equal(calls, 1);
  assert.equal(app.history[0].content, 'Ekli dosyaları analiz et.');
  assert.equal(app.history[0].apiContent, 'Ekli dosyaları analiz et.');
});

test('streamed fence and token fragments keep a single code block throughout the actual reply flow', async t => {
  const { w, app } = setup(t, { markdown: true });
  app.history = [{ role: 'user', content: 'Java ve HTML örneği göster' }];
  app.streaming = true;
  let controller;
  w.fetch = async () => new Response(new ReadableStream({ start(value) { controller = value; } }),
    { headers: { 'content-type': 'text/event-stream' } });
  const pending = app.generateAssistantReply();
  await new Promise(resolve => setImmediate(resolve));
  const first = '\tpublic void run() {\n\t\tcall("<x> &lt; && Türkçe 🙂");  \n\t}\n';
  const second = '<div>**literal** &amp;</div>\n';
  const chunks = ['İlk örnek:\n\n`', '`', '`ja', 'va\n', first.slice(0, 22), first.slice(22), '`', '`', '`\n\nİkinci örnek:\n\n~', '~~ht', 'ml\n', second, '~', '~~\n\nBitti.'];
  let source = '';
  for (const [index, chunk] of chunks.entries()) {
    source += chunk;
    controller.enqueue(new TextEncoder().encode(event(chunk)));
    await new Promise(resolve => setImmediate(resolve));
    assert.equal(app.history.at(-1).content, source, `full source after chunk ${index}`);
    const bubble = w.document.querySelector('.streaming-message');
    assert.ok(bubble, 'stream uses the production message bubble');
    if (index >= 3 && index <= 8) {
      assert.equal(bubble.querySelectorAll('pre code').length, 1, `one code block after chunk ${index}`);
    }
    if (index >= 8) assert.equal(codeTexts(bubble)[0], first);
    if (index === chunks.length - 1) assert.deepEqual(codeTexts(bubble), [first, second]);
    assert.equal(bubble.querySelector('pre x, pre div'), null);
  }
  controller.enqueue(new TextEncoder().encode(event('', 'stop') + 'data: [DONE]\n\n'));
  controller.close();
  await pending;
  assert.equal(app.history[1].content, source);
  assert.equal(app.savedHistory[1].content, source);
  assert.deepEqual(codeTexts(w.document.getElementById('messagesInner')), [first, second]);
  assert.equal(w.document.querySelectorAll('.code-block-wrapper').length, 2);
  assert.equal(w.document.querySelector('.streaming-message'), null);
});

test('interrupted streaming preserves an unfinished code fence as a single copyable block', async t => {
  const { w, app } = setup(t, { markdown: true });
  const copied = captureClipboard(w);
  app.history = [{ role: 'user', content: 'Java göster' }];
  app.streaming = true;
  const payload = '\tpublic void run() {\n\t\tcall("<x>&");  ';
  w.fetch = async () => sse([event('Açıklama\n\n```java\n'), event(payload)]);
  await app.generateAssistantReply();
  assert.equal(app.history[1].content, 'Açıklama\n\n```java\n' + payload);
  const node = w.document.getElementById('messagesInner');
  assert.equal(app.history[2].role, 'error');
  assert.equal(node.querySelector('pre code').textContent, payload);
  node.querySelector('.code-copy-btn[title="Kodu kopyala"]').click();
  await Promise.resolve();
  assert.deepEqual(copied, [payload]);
});
function sse(chunks, failure) {
  let index = 0;
  return new Response(new ReadableStream({
    pull(controller) {
      if (index < chunks.length) controller.enqueue(new TextEncoder().encode(chunks[index++]));
      else if (failure) controller.error(new Error(failure));
      else controller.close();
    },
  }), { headers: { 'content-type': 'text/event-stream' } });
}
function seed(app) {
  app.history = [
    { role: 'user', content: 'Dosyayı özetle', apiContent: 'Dosyayı özetle\n\n--- Dosya: surec.txt ---\nBaşvuru > Onay', attachments: [{ name: 'surec.txt' }] },
    { role: 'assistant', content: 'Başvuru incelenir ve onaylanır.' },
  ];
}

function captureDownload(w) {
  let content;
  w.Blob = class { constructor(parts) { content = parts.join(''); } };
  w.URL.createObjectURL = () => 'blob:mock';
  w.URL.revokeObjectURL = () => {};
  w.HTMLAnchorElement.prototype.click = () => {};
  return () => content;
}

async function importSettingsFile(w, app, data) {
  const createElement = w.document.createElement.bind(w.document);
  let input;
  w.document.createElement = (tag, ...args) => {
    const element = createElement(tag, ...args);
    if (tag === 'input') { input = element; element.click = () => {}; }
    return element;
  };
  app.importSettings();
  w.document.createElement = createElement;
  Object.defineProperty(input, 'files', { value: [{ text: async () => JSON.stringify(data) }] });
  input.dispatchEvent(new w.Event('change'));
  await new Promise(resolve => setImmediate(resolve));
}

async function seedKnowledgeBase(app, chunks) {
  const db = await app.openRAGDB();
  const tx = db.transaction(['documents', 'chunks'], 'readwrite');
  tx.objectStore('documents').put({
    id: 'test-document', name: 'knowledge.txt', size: 100, type: 'txt', createdAt: 1,
    chunkCount: chunks.length,
  });
  chunks.forEach((chunk, index) => tx.objectStore('chunks').put({
    docId: 'test-document', index, text: 'A stored passage', ...chunk,
  }));
  await new Promise((resolve, reject) => {
    tx.oncomplete = resolve;
    tx.onerror = () => reject(tx.error);
  });
  db.close();
}

test('full storage cannot erase loaded conversations, and failed saves warn without replacing saved data', t => {
  const { w, app } = setup(t);
  seed(app);
  app.saveHistory();
  app.startNewConversation();
  app.history = [{ role: 'user', content: 'İkinci sohbet' }];
  app.saveHistory();
  const saved = w.localStorage.getItem(app.conversationsKey);
  const original = w.Storage.prototype.setItem;
  w.Storage.prototype.setItem = () => { throw new w.DOMException('quota', 'QuotaExceededError'); };
  app.loadHistory();
  assert.equal(app.conversations.length, 2);
  assert.equal(app.history[0].content, 'İkinci sohbet');
  app.history.push({ role: 'assistant', content: 'Yeni yanıt' });
  app.saveHistory();
  assert.equal(w.localStorage.getItem(app.conversationsKey), saved);
  assert.match(w.document.body.textContent, /Sohbet kaydedilemedi/);
  w.Storage.prototype.setItem = original;
  app.saveHistory();
  app.loadHistory();
  assert.equal(app.conversations.length, 2);
  assert.equal(app.history[1].content, 'Yeni yanıt');
  assert.equal(w.localStorage.getItem(app.historyKey), null);
});

test('legacy history survives failed migration and is removed only after a successful save', t => {
  const { w, app } = setup(t);
  const legacy = JSON.stringify([{ role: 'user', content: 'Eski kayıt' }]);
  w.localStorage.setItem(app.historyKey, legacy);
  const original = w.Storage.prototype.setItem;
  w.Storage.prototype.setItem = () => { throw new w.DOMException('quota', 'QuotaExceededError'); };
  app.loadHistory();
  app.saveHistory();
  assert.equal(app.history[0].content, 'Eski kayıt');
  assert.equal(w.localStorage.getItem(app.historyKey), legacy);
  w.Storage.prototype.setItem = original;
  app.saveHistory();
  assert.equal(app.savedHistory[0].content, 'Eski kayıt');
  assert.equal(w.localStorage.getItem(app.historyKey), null);
});

test('unreadable saved history is protected from subsequent writes', t => {
  const { w, app } = setup(t);
  w.localStorage.setItem(app.conversationsKey, '{damaged');
  app.loadHistory();
  app.history = [{ role: 'user', content: 'Yeni mesaj' }];
  app.saveHistory();
  assert.equal(w.localStorage.getItem(app.conversationsKey), '{damaged');
  assert.match(w.document.body.textContent, /üzerine yazılmadı/);
});

test('configured HTML includes settings but excludes conversations, drafts, searches and previews', t => {
  const { w, app } = setup(t);
  app.history = [{ role: 'user', content: 'PRIVATE_CONVERSATION' }];
  app.saveHistory();
  app.renderMessages();
  w.document.getElementById('userInput').textContent = 'PRIVATE_DRAFT';
  w.document.getElementById('printArea').textContent = 'PRIVATE_PRINT';
  w.document.getElementById('globalSearchResults').textContent = 'PRIVATE_SEARCH';
  w.document.getElementById('artifactIframe').setAttribute('srcdoc', 'PRIVATE_PREVIEW');
  app.config.headers = { Authorization: 'Bearer test-$&-token' };
  app.config.embedding = { model: 'legacy-setting-that-must-not-export' };
  app.fillSettingsForm();
  const download = captureDownload(w);
  app.downloadClone();
  const clonedHtml = download();
  assert.doesNotMatch(clonedHtml, /PRIVATE_(CONVERSATION|DRAFT|PRINT|SEARCH|PREVIEW)/);
  assert.match(clonedHtml, /Bearer test-\$&-token/);
  assert.doesNotMatch(clonedHtml, /legacy-setting-that-must-not-export/);
  const clone = new JSDOM(clonedHtml, { runScripts: 'outside-only' });
  t.after(() => clone.window.close());
  const script = [...clone.window.document.scripts].find(s => s.textContent.includes('async function summarizeConversation()')).textContent;
  new (require('node:vm').Script)(script);
  const defaults = script.match(/\/\* DEFAULT_CONFIG_START \*\/([\s\S]*?)\/\* DEFAULT_CONFIG_END \*\//)[1];
  const clonedConfig = JSON.parse(clone.window.eval(defaults + '\nJSON.stringify(apiConfig)'));
  assert.equal(Object.hasOwn(clonedConfig, 'embedding'), false);
});

test('RAG locks send and conversation changes until one response completes', async t => {
  const { w, app } = setup(t);
  seed(app);
  app.saveHistory();
  const origin = app.activeId;
  let release;
  let searches = 0;
  app.rag = true;
  app.augment = () => { searches++; return new Promise(resolve => { release = resolve; }); };
  let calls = 0;
  w.fetch = async () => { calls++; return jsonReply('Yanıt'); };
  w.document.getElementById('userInput').value = 'Tek soru';
  const pending = app.sendMessage();
  assert.equal(app.busy, true);
  assert.equal(w.document.getElementById('sendBtn').disabled, true);
  await app.sendMessage();
  app.startNewConversation();
  assert.equal(app.activeId, origin);
  assert.equal(searches, 1);
  release(' Kaynak bilgisi');
  await pending;
  assert.equal(calls, 1);
  assert.equal(app.history.filter(m => m.content === 'Tek soru').length, 1);
  assert.equal(app.conversations.length, 1);
  assert.equal(app.busy, false);
});

test('stopping during RAG aborts preparation while keeping the draft and its files', async t => {
  const { w, app } = setup(t);
  app.rag = true;
  app.files = [{ name: 'a.txt', content: 'Dosya' }];
  app.augment = (_, signal) => new Promise((_, reject) => {
    signal.addEventListener('abort', () => reject(new DOMException('Aborted', 'AbortError')));
  });
  w.document.getElementById('userInput').value = 'Gönderilmemiş soru';
  const pending = app.sendMessage();
  app.stopGeneration();
  await pending;
  assert.equal(app.history.length, 0);
  assert.equal(app.files[0].content, 'Dosya');
  assert.equal(w.document.getElementById('userInput').value, 'Gönderilmemiş soru');
  assert.equal(app.controller, null);
  assert.equal(app.busy, false);
});

test('keyword ranking uses whole words, Turkish suffix stemming and BM25 weighting', t => {
  const { app } = setup(t);
  const chunks = [
    { id: 'a', text: 'Ürün iadesi 14 gün içinde yapılır. İade koşulları geçerlidir.' },
    { id: 'b', text: 'Para transferi ve ödeme bilgileri burada yer alır.' },
    { id: 'c', text: 'Genel bilgiler ve ödeme bilgileri hakkında açıklama bilgiler.' },
  ];
  const ids = query => Array.from(app.rankKeywordChunks(chunks, query, 5), c => c.id);
  assert.deepEqual(ids('iade süresi'), ['a'], 'suffix "iadesi" matches "iade"');
  assert.deepEqual(ids('ara'), [], '"ara" must not match inside "para"');
  assert.deepEqual(ids('ödeme bilgileri').sort(), ['b', 'c']);
  assert.deepEqual(ids('ve'), [], 'short words are ignored');
  assert.deepEqual(Array.from(app.rankKeywordChunks(chunks, 'iade', 0)), []);
});

test('embedding UI and network calls are removed while RAG remains keyword-only', async t => {
  const { w, app } = setup(t);
  assert.equal(w.document.getElementById('apiEmbeddingPanel'), null);
  assert.equal(w.document.getElementById('cfgEmbeddingModel'), null);
  assert.equal(w.document.getElementById('reindexKBBtn'), null);
  assert.doesNotMatch(w.document.getElementById('settingsPanel').textContent, /embedding/i);

  app.config.embedding = { model: 'legacy-setting' };
  app.saveConfigToLS();
  assert.equal(Object.hasOwn(JSON.parse(w.localStorage.getItem('aiChat.apiConfig.v1')), 'embedding'), false);
  app.loadConfig();
  assert.equal(Object.hasOwn(app.config, 'embedding'), false);

  await seedKnowledgeBase(app, [
    { id: 'legacy-vector', text: 'Semantic only', embedding: [1, 0] },
    { id: 'keyword', text: 'needle remains searchable' },
  ]);
  let fetchCalls = 0;
  w.fetch = async () => { fetchCalls++; throw new Error('Embedding endpoint must not be called'); };
  const results = await app.searchRAG('needle');
  assert.deepEqual(results.map(result => result.text), ['needle remains searchable']);
  assert.equal(fetchCalls, 0);
});

test('editing an old attached message retains file context without repeating the previous prompt or RAG context', async t => {
  const { w, app } = setup(t);
  seed(app);
  app.history[0].apiContent += '\n\n--- Bilgi Tabanından Bulunan Bağlam ---\nESKI_RAG';
  app.beginEditMessage(0);
  assert.equal(app.files[0].content, 'Başvuru > Onay');
  let body;
  w.fetch = async (_, options) => { body = JSON.parse(options.body); return jsonReply('Yeni özet'); };
  w.document.getElementById('userInput').value = 'Daha ayrıntılı özetle';
  await app.sendMessage();
  assert.match(body.messages[0].content, /Daha ayrıntılı özetle/);
  assert.match(body.messages[0].content, /Başvuru > Onay/);
  assert.doesNotMatch(body.messages[0].content, /ESKI_RAG|Dosyayı özetle/);
  assert.equal(app.history[0].attachments[0].content, 'Başvuru > Onay');
  app.loadHistory();
  app.beginEditMessage(0);
  assert.equal(app.files[0].content, 'Başvuru > Onay');
  app.cancelEditMode(true);
  assert.equal(app.files.length, 0);
});

test('editing multiple legacy files allows removing one while preserving the other', async t => {
  const { w, app } = setup(t);
  app.history = [{ role: 'user', content: 'Özetle', apiContent: 'Özetle\n\n--- Dosya: a.txt ---\nAAA\n\n--- Dosya: b.txt ---\nBBB', attachments: [{ name: 'a.txt' }, { name: 'b.txt' }] }];
  app.beginEditMessage(0);
  w.document.querySelector('[data-remove-file="0"]').click();
  w.document.getElementById('userInput').value = 'Kalanı özetle';
  w.fetch = async (_, options) => {
    const text = JSON.parse(options.body).messages[0].content;
    assert.doesNotMatch(text, /AAA|a.txt/);
    assert.match(text, /b.txt.*\nBBB/);
    return jsonReply('Özet');
  };
  await app.sendMessage();
  assert.equal(app.history[0].attachments.length, 1);
  assert.equal(app.history.at(-1).role, 'assistant');
});

for (const streaming of [false, true]) {
  test(`images use multimodal content and survive history reload and follow-up ${streaming ? 'streaming' : 'JSON'} requests`, async t => {
    const { w, app } = setup(t);
    app.streaming = streaming;
    const image = 'data:image/png;base64,AAAA';
    app.files = [{ name: 'photo.png', type: 'image/png', content: image }, { name: 'notes.txt', content: 'Notlar' }];
    w.document.getElementById('userInput').value = 'Görseli anlat';
    const requests = [];
    w.fetch = async (_, options) => {
      requests.push(JSON.parse(options.body));
      return streaming ? sse([event('Açıklama', 'stop'), 'data: [DONE]']) : jsonReply('Açıklama');
    };
    await app.sendMessage();
    app.loadHistory();
    w.document.getElementById('userInput').value = 'Devam et';
    await app.sendMessage();
    assert.equal(requests.length, 2);
    for (const request of requests) {
      const parts = request.messages[0].content;
      assert.ok(Array.isArray(parts));
      assert.equal(parts[0].type, 'text');
      assert.match(parts[0].text, /Görseli anlat.*\n\n--- Dosya: notes.txt ---\nNotlar/);
      assert.doesNotMatch(parts[0].text, /base64/);
      assert.equal(parts[1].type, 'image_url');
      assert.equal(parts[1].image_url.url, image);
    }
    app.beginEditMessage(0);
    assert.equal(app.files[0].content, image);
  });
}

test('images embedded in legacy history become image parts without repeating base64 in text', t => {
  const { app } = setup(t);
  const image = 'data:image/png;base64,AAAA';
  const message = { role: 'user', content: 'Görseli anlat', apiContent: 'Görseli anlat\n\n--- Dosya: old.png ---\n' + image, attachments: [{ name: 'old.png', type: 'image/png' }] };
  const parts = app.getApiMessageContent(message);
  assert.equal(parts[0].text, 'Görseli anlat');
  assert.equal(parts[1].image_url.url, image);
});

test('models retain explicit image capabilities after loading, editing and reloading', t => {
  const { w, app } = setup(t);
  const key = 'aiChat.customModels.v1';
  w.localStorage.setItem(key, JSON.stringify([
    { id: 'test', name: 'Image model', vision: true },
    { id: 'text-only', name: 'Text model', vision: false },
    { id: 'unknown', name: 'Unknown model' },
    { id: 'Qwen/Qwen3.5-27B', name: 'Legacy default without capability' },
  ]));
  app.loadCustomModels();
  for (const [id, expected] of [['test', true], ['text-only', false], ['unknown', undefined], ['Qwen/Qwen3.5-27B', true]]) {
    assert.equal(app.settings.customModels.find(model => model.id === id).vision, expected);
  }
  w.document.getElementById('modelDefinitionId').value = 'text-only';
  w.document.getElementById('modelDefinitionName').value = 'Renamed text model';
  w.document.getElementById('modelDefinitionForm').dispatchEvent(new w.Event('submit', { bubbles: true, cancelable: true }));
  app.loadCustomModels();
  const models = JSON.parse(w.localStorage.getItem(key));
  assert.equal(models.find(model => model.id === 'text-only').name, 'Renamed text model');
  assert.equal(models.find(model => model.id === 'text-only').vision, false);
  assert.equal(models.find(model => model.id === 'test').vision, true);
  assert.equal(models.find(model => model.id === 'Qwen/Qwen3.5-27B').vision, true);
});

test('embedded default image capability survives first startup and later model reloads', t => {
  const { app } = setup(t);
  const message = { role: 'user', content: 'Describe', attachments: [{ name: 'photo.png', content: 'data:image/png;base64,AAAA' }] };
  app.config.bodyTemplate = '{"messages":[{"role":"user","content":"$PROMPT"}],"model":"Qwen/Qwen3.5-27B"}';
  for (let reload = 0; reload < 2; reload++) {
    app.loadCustomModels();
    assert.equal(app.settings.customModels.find(model => model.id === 'Qwen/Qwen3.5-27B').vision, true);
    assert.equal(app.getApiMessageContent(message)[1].image_url.url, message.attachments[0].content);
  }
});

test('explicit text-only models omit image data without losing images when capability changes', t => {
  const { app } = setup(t);
  const image = 'data:image/png;base64,AAAA';
  const model = { id: 'test', name: 'Test model', vision: false };
  app.settings.customModels.push(model);
  const messages = [
    { role: 'user', content: 'Describe', attachments: [{ name: 'photo.png', content: image }] },
    { role: 'user', content: 'Describe', apiContent: 'Describe\n\n--- Dosya: photo.png ---\n' + image, attachments: [{ name: 'photo.png' }] },
  ];
  const original = JSON.stringify(messages);
  for (const message of messages) {
    const text = app.getApiMessageContent(message);
    assert.equal(typeof text, 'string');
    assert.match(text, /görsel API'ye gönderilmedi/);
    assert.doesNotMatch(text, /base64|--- Dosya:/);
  }
  model.vision = true;
  for (const message of messages) {
    const parts = app.getApiMessageContent(message);
    assert.equal(parts[0].text, 'Describe');
    assert.equal(parts[1].image_url.url, image);
  }
  delete model.vision;
  assert.equal(app.getApiMessageContent(messages[0])[1].image_url.url, image, 'unspecified capability does not discard attachments');
  assert.equal(JSON.stringify(messages), original);
});

test('the complete app starts normally and can reload a stored conversation', t => {
  const dom = new JSDOM(html, { url: 'http://localhost/', runScripts: 'outside-only', virtualConsole: new VirtualConsole() });
  t.after(() => dom.window.close());
  const w = dom.window;
  w.localStorage.setItem('aiChat.conversations.v1', JSON.stringify([{ id: 'startup', title: 'Kayıtlı', messages: [{ role: 'user', content: 'Açılış testi' }] }]));
  const script = [...w.document.scripts].find(s => s.textContent.includes('async function summarizeConversation()')).textContent;
  assert.doesNotThrow(() => w.eval(script));
  assert.match(w.document.getElementById('messagesInner').textContent, /Açılış testi/);
  assert.equal(w.document.getElementById('sendBtn').disabled, false);
});

test('exported settings import fully, including templates and the settings after them', async t => {
  const { w, app } = setup(t);
  app.config.embedding = { model: 'legacy-setting-that-must-not-export' };
  const download = captureDownload(w);
  app.exportSettings();
  const exported = JSON.parse(download());
  assert.equal(Object.hasOwn(exported.apiConfig, 'embedding'), false);
  exported.apiConfig.embedding = { model: 'legacy-setting-that-must-be-ignored' };
  exported.promptTemplates = [{ id: 'test-template', title: 'Test', prompt: 'Test promptu', icon: 'T', description: '', placeholder: '', isCustom: true }];
  exported.customModels = [{ id: 'test-model', name: 'Test model' }];
  exported.systemPrompt = 'İçe aktarılan sistem promptu';
  exported.streamingEnabled = true;
  exported.ragEnabled = true;
  await importSettingsFile(w, app, exported);
  assert.equal(app.settings.promptTemplates[0].prompt, 'Test promptu');
  assert.equal(app.settings.systemPrompt, exported.systemPrompt);
  assert.equal(app.settings.streamingEnabled, true);
  assert.equal(app.settings.ragEnabled, true);
  assert.equal(Object.hasOwn(app.config, 'embedding'), false);
  assert.equal(Object.hasOwn(JSON.parse(w.localStorage.getItem('aiChat.apiConfig.v1')), 'embedding'), false);
  assert.match(w.document.body.textContent, /Ayarlar başarıyla içe aktarıldı/);
  app.loadPromptTemplates();
  assert.equal(app.settings.promptTemplates[0].id, 'test-template');
});

test('invalid settings are rejected before applying earlier fields', async t => {
  const { w, app } = setup(t);
  const previousUrl = app.config.url;
  await importSettingsFile(w, app, { apiConfig: { url: 'http://changed/' }, promptTemplates: 'bad' });
  assert.equal(app.config.url, previousUrl);
  assert.match(w.document.body.textContent, /Geçersiz ayar listesi/);
});

test('auto-tagging sends the actual instruction and preserves the conversation messages', async t => {
  const { w, app } = setup(t);
  seed(app);
  app.saveHistory();
  const previous = JSON.stringify(app.history);
  w.fetch = async (_, options) => {
    const messages = JSON.parse(options.body).messages;
    assert.equal(app.busy, true);
    assert.match(messages[0].content, /Türkçe etiket öner/);
    assert.match(messages[0].content, /user: Dosyayı özetle/);
    return jsonReply('Başvuru, Onay');
  };
  await app.autoTagConversation();
  assert.equal(JSON.stringify(app.history), previous);
  assert.deepEqual([...app.conversations[0].tags], ['Başvuru', 'Onay']);
  assert.equal(app.busy, false);
});

test('usage statistics count totals once, fall back to components and respect zero', t => {
  const { w, app } = setup(t);
  app.history = [
    { role: 'assistant', content: 'A', usage: { total_tokens: 15, prompt_tokens: 10, completion_tokens: 5 } },
    { role: 'assistant', content: 'B', usage: { prompt_tokens: 10, completion_tokens: 5 } },
    { role: 'assistant', content: 'C', usage: { input_tokens: '3', output_tokens: '5' } },
    { role: 'assistant', content: 'D', usage: { total_tokens: 0, prompt_tokens: 10, completion_tokens: 5 } },
  ];
  app.saveHistory();
  let stats;
  w.alert = text => { stats = text; };
  app.showUsageStats();
  assert.match(stats, /Toplam token: 38/);
});

test('conversation summary sends a JSON object, file context and the summary request exactly once', async t => {
  const { w, app } = setup(t);
  seed(app);
  app.config.bodyTemplate = '{"messages":[{"role":"system","content":"Yardımcı ol"},{"role":"user","content":"$PROMPT"}],"stream":true,"stream_options":{"include_usage":true}}';
  w.fetch = async (_, options) => {
    const body = JSON.parse(options.body);
    assert.equal(typeof body, 'object');
    assert.equal(body.messages.length, 4);
    assert.match(body.messages[1].content, /surec.txt/);
    assert.match(body.messages[3].content, /sohbetimizi.*özetle/);
    assert.equal(body.stream, false);
    assert.equal(body.stream_options, undefined);
    return jsonReply('Karar: Başvuru onaylanır.');
  };
  await app.summarizeConversation();
  assert.equal(app.history.length, 3);
  assert.match(app.history[2].content, /Sohbet Özeti.*\n\nKarar:/);
  assert.equal(app.history[2].usage.total_tokens, 15);
  assert.equal(app.busy, false);
  assert.equal(app.controller, null);
  assert.match(w.document.getElementById('messagesInner').textContent, /Karar:/);
});

for (const [label, response] of [
  ['empty content', () => jsonReply('  ')],
  ['null content', () => jsonReply(null)],
  ['missing response path', () => new Response('{}')],
  ['HTTP failure', () => new Response('unavailable', { status: 503 })],
]) {
  test(`failed summary (${label}) leaves the conversation intact`, async t => {
    const { w, app } = setup(t);
    seed(app);
    const before = JSON.stringify(app.history);
    w.fetch = async () => response();
    await app.summarizeConversation();
    assert.equal(JSON.stringify(app.history), before);
    assert.equal(app.busy, false);
    assert.equal(app.controller, null);
    assert.match(w.document.body.textContent, /Özetleme başarısız/);
  });
}

test('file summary followed by a streamed diagram retains context and renders the completed diagram once', async t => {
  const { w, app } = setup(t);
  let calls = 0;
  const rendered = [];
  w.mermaid = { render: async (_, source) => { rendered.push(source); return { svg: '<svg><text>Başvuru → Onay</text></svg>' }; } };
  w.fetch = async (_, options) => {
    const body = JSON.parse(options.body);
    calls++;
    if (calls === 1) return jsonReply('Dosyada başvuru ve onay aşamaları var.');
    assert.match(body.messages[0].content, /surec.txt.*\nBaşvuru > Onay/);
    assert.equal(body.messages.at(-1).content, 'Diagram oluştur');
    assert.equal(body.messages.at(-1).role, 'user');
    assert.equal(body.stream, true);
    return sse([event('Akış:\n\n```mermaid\n'), event('graph TD\n A[Başvuru] --> B[Onay]\n'), event('```\n\nTamamlandı.', 'stop'), 'data: [DONE]']);
  };
  app.files = [{ name: 'surec.txt', content: 'Başvuru > Onay', size: 30, type: 'text/plain' }];
  w.document.getElementById('userInput').value = 'Dosyayı özetle';
  await app.sendMessage();
  app.streaming = true;
  w.document.getElementById('userInput').value = 'Diagram oluştur';
  await app.sendMessage();
  await Promise.resolve();
  assert.equal(app.history.length, 4);
  assert.match(app.history[3].content, /Tamamlandı\.$/);
  assert.equal(rendered.length, 1);
  const card = w.document.querySelector('#messagesInner .mermaid-diagram-card');
  assert.ok(card?.querySelector('svg'));
  assert.match(card.querySelector('pre').textContent, /graph TD/);
  assert.equal(app.busy, false);
  assert.equal(app.savedHistory[3].content, app.history[3].content);
  assert.match(w.document.getElementById('messagesInner').textContent, /Tamamlandı/);
});

test('Chart.js code remains attached to the message with its canvas', t => {
  const { w, app } = setup(t);
  let charts = 0;
  w.HTMLCanvasElement.prototype.getContext = () => ({});
  w.Chart = function () { charts++; };
  const node = app.buildMessageNode({ role: 'assistant', content: '```chart\n{"type":"bar","data":{"labels":["A"],"datasets":[]}}\n```' }, 0);
  assert.ok(node.querySelector('.mermaid-diagram-card canvas'));
  assert.ok(node.querySelector('.mermaid-diagram-card pre'));
  assert.equal(charts, 1);
});

test('invalid Mermaid shows source code and a readable failure', async t => {
  const { w, app } = setup(t);
  w.mermaid = { render: async () => { throw new Error('syntax'); } };
  const node = app.buildMessageNode({ role: 'assistant', content: '```mermaid\ninvalid diagram\n```' }, 0);
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(node.querySelector('pre').classList.contains('hidden'), false);
  assert.match(node.textContent, /Diyagram oluşturulamadı/);
});

test('Mermaid retries the screenshot PIPE error in an isolated host and enables SVG actions only on success', async t => {
  const { w, app } = setup(t);
  const source = 'graph TD\n Android[<b>Android Stack</b><br/>Kotlin 2.0.21 | Min SDK 24<br/>Koin] --> Goal[Integration]';
  const calls = [];
  let finishRender;
  w.mermaid = {
    render(id, input, host) {
      calls.push({ id, input, host, attached: host?.isConnected });
      if (host) {
        const artifact = w.document.createElement('div');
        artifact.className = 'test-mermaid-render-artifact';
        artifact.textContent = 'Syntax error in text';
        host.appendChild(artifact);
      }
      if (calls.length === 1) return Promise.reject(new Error("Expecting 'TEXT', got 'PIPE'"));
      return new Promise(resolve => { finishRender = resolve; });
    },
  };
  const node = app.buildMessageNode({ role: 'assistant', content: '```mermaid\n' + source + '\n```' }, 0);
  w.document.getElementById('messagesInner').appendChild(node);
  const card = node.querySelector('.mermaid-diagram-card');
  const copy = card.querySelector('.mermaid-copy-btn');
  const zoom = card.querySelector('.mermaid-zoom-btn');
  assert.equal(copy.disabled, true);
  assert.equal(zoom.disabled, true);
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(calls.length, 2);
  assert.equal(calls[0].input, source);
  assert.match(calls[1].input, /Android\["<b>Android Stack<\/b><br\/>Kotlin 2\.0\.21 \| Min SDK 24<br\/>Koin"\]/);
  assert.ok(calls.every(call => call.attached), 'render receives a host attached to the document');
  assert.equal(calls[0].host.isConnected, false, 'failed attempt host is removed before retry');
  assert.equal(copy.disabled, true);
  assert.equal(zoom.disabled, true);
  finishRender({ svg: '<svg><text>Android diagram</text></svg>' });
  await new Promise(resolve => setImmediate(resolve));
  assert.ok(calls.every(call => !call.host.isConnected), 'all render hosts are removed');
  assert.equal(w.document.querySelector('.test-mermaid-render-artifact'), null);
  assert.match(card.querySelector('.mermaid-body svg').textContent, /Android diagram/);
  assert.equal(card.querySelector('pre code').textContent.trim(), source, 'the original source stays available');
  assert.equal(copy.disabled, false);
  assert.equal(zoom.disabled, false);
  zoom.click();
  assert.match(w.document.getElementById('mermaidModalBody').textContent, /Android diagram/);
});

test('valid Mermaid source is rendered unchanged without a speculative repair', async t => {
  const { w, app } = setup(t);
  const source = 'flowchart LR\n A["Kotlin | SDK (24)"] -->|"contains | pipe"| B{Approved?}\n %% C[comment | left intact]';
  const inputs = [];
  w.mermaid = { render: async (_, input) => { inputs.push(input); return { svg: '<svg></svg>' }; } };
  const node = app.buildMessageNode({ role: 'assistant', content: '```mermaid\n' + source + '\n```' }, 0);
  await new Promise(resolve => setImmediate(resolve));
  assert.deepEqual(inputs, [source]);
  assert.ok(node.querySelector('.mermaid-body svg'));
});

for (const [shape, nodeSource, quotedSource] of [
  ['square', 'A[Android | Min SDK 24]', 'A["Android | Min SDK 24"]'],
  ['rounded', 'A(Android | Min SDK 24)', 'A("Android | Min SDK 24")'],
  ['diamond', 'A{Android | Min SDK 24}', 'A{"Android | Min SDK 24"}'],
]) {
  test(`Mermaid recovery quotes ${shape} node labels without changing edge labels, comments or quoted nodes`, async t => {
    const { w, app } = setup(t);
    const context = '\n B["Already | quoted"] -->|SDK[24]| C[Done]\n %% D[comment | untouched]';
    const source = 'flowchart TD\n ' + nodeSource + context;
    const inputs = [];
    w.mermaid = {
      render: async (_, input) => {
        inputs.push(input);
        if (input.includes(nodeSource)) throw new Error("Parse error: got 'PIPE'");
        return { svg: '<svg><text>Recovered</text></svg>' };
      },
    };
    const node = app.buildMessageNode({ role: 'assistant', content: '```mermaid\n' + source + '\n```' }, 0);
    await new Promise(resolve => setImmediate(resolve));
    assert.equal(inputs.length, 2);
    assert.ok(inputs[1].includes(quotedSource));
    assert.ok(inputs[1].includes('B["Already | quoted"] -->|SDK[24]|'));
    assert.ok(inputs[1].includes('%% D[comment | untouched]'));
    assert.ok(node.querySelector('.mermaid-body svg'));
  });
}

test('Mermaid can recover both an invalid init directive and an unquoted label', async t => {
  const { w, app } = setup(t);
  const source = '%%{init: invalid}%%\ngraph TD\n A[Kotlin | SDK]';
  const calls = [];
  w.mermaid = {
    render: async (_, input, host) => {
      calls.push({ input, host });
      if (input.includes('%%{init:') || input.includes('A[Kotlin | SDK]')) throw new Error('Parse error');
      return { svg: '<svg><text>Recovered</text></svg>' };
    },
  };
  const node = app.buildMessageNode({ role: 'assistant', content: '```mermaid\n' + source + '\n```' }, 0);
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(calls[0].input, source);
  assert.ok(calls.length <= 4, 'recovery is bounded');
  assert.ok(calls.at(-1).input.includes('A["Kotlin | SDK"]'));
  assert.ok(calls.every(call => call.host && !call.host.isConnected));
  assert.ok(node.querySelector('.mermaid-body svg'));
});

for (const [grammar, markdown] of [['stateDiagram-v2', false], ['stateDiagram-v2', true], ['stateDiagram', true]]) {
  test(`Mermaid ${grammar} recovers the screenshot section heading with ${markdown ? 'real Markdown' : 'offline fallback'}`, async t => {
    const { w, app } = setup(t, { markdown });
    const source = [
      grammar,
      '    direction TB',
      '',
      '    [*] --> IslemSecimi: Giriş',
      '    IslemSecimi --> OdemeOlusturAkisi: "Taksitli Ödeyeceğim" Seçimi',
      '    IslemSecimi --> OdemeTalepEtAkisi: "Taksitli Ödensin" Seçimi',
      '',
      '    -- Ödeme Oluşturma Akışı --',
      '    OdemeOlusturAkisi --> InputValidasyonu: Kullanıcı Girişi',
      '    InputValidasyonu --> ValidasyonKontrolu',
      '    ValidasyonKontrolu --> TaksitHesaplama: "Validasyon Başarılı"',
    ].join('\n');
    const calls = [];
    const svg = '<svg><text>Ödeme Oluşturma Akışı</text></svg>';
    w.mermaid = {
      render: async (_, input, host) => {
        calls.push({ input, host });
        if (input.split('\n').includes('    -- Ödeme Oluşturma Akışı --')) {
          throw new Error("Parse error on line 8: Expecting 'SPACE', 'NL', 'STATE_DESCR'");
        }
        return { svg };
      },
    };
    const message = { role: 'assistant', content: '```mermaid\n' + source + '\n```' };
    const originalMessage = JSON.stringify(message);
    const node = app.buildMessageNode(message, 0);
    await new Promise(resolve => setImmediate(resolve));
    assert.equal(calls.length, 2);
    assert.equal(calls[0].input, source, 'try the supplied diagram before repairing it');
    const repairedLines = calls[1].input.split('\n');
    assert.match(repairedLines[7], /^\s*%%.*Ödeme Oluşturma Akışı/);
    assert.deepEqual(repairedLines.filter((_, i) => i !== 7), source.split('\n').filter((_, i) => i !== 7));
    assert.equal(node.querySelector('.mermaid-body svg').textContent, 'Ödeme Oluşturma Akışı');
    assert.equal(node.querySelector('pre code').textContent, source + '\n');
    assert.equal(JSON.stringify(message), originalMessage, 'repair is only a rendering fallback');
    assert.equal(node.querySelector('.mermaid-copy-btn').disabled, false);
    assert.equal(node.querySelector('.mermaid-zoom-btn').disabled, false);
    assert.ok(calls.every(call => call.host && !call.host.isConnected));
  });
}

for (const failsFirst of [false, true]) {
  test(`Mermaid state ${failsFirst ? 'heading recovery preserves' : 'rendering does not preemptively change'} notes, labels and concurrent regions`, async t => {
    const { w, app } = setup(t);
    const preserved = [
      'stateDiagram-v2',
      'state Parallel {',
      '    [*] --> Waiting',
      '    Waiting --> Done: -- successful result --',
      '    --',
      '    [*] --> Logging',
      '}',
      'Done: -- visible state description --',
      'state "-- visible quoted title --" as Quoted',
      'state "A multiline title',
      '-- visible title section --',
      'Last title line" as Multiline',
      'note right of Waiting',
      '    -- visible note section --',
      '    A note with an unmatched "quote',
      'end note',
      'note left of Done: -- visible inline note --',
      'NOTE RIGHT OF Done',
      '    -- visible uppercase note section --',
      'END NOTE',
      'accDescr {',
      '    -- visible accessible description --',
      '}',
      'ACCDESCR {',
      '    -- visible uppercase accessible description --',
      '}',
      '%% -- existing comment stays as written --',
    ].join('\n');
    const source = preserved + '\n-- Payment processing --\nDone --> [*]';
    const inputs = [];
    w.mermaid = {
      render: async (_, input) => {
        inputs.push(input);
        if (failsFirst && inputs.length === 1) throw new Error('Parse error at Payment processing');
        return { svg: '<svg><text>States</text></svg>' };
      },
    };
    const node = app.buildMessageNode({ role: 'assistant', content: '```mermaid\n' + source + '\n```' }, 0);
    await new Promise(resolve => setImmediate(resolve));
    assert.equal(inputs[0], source);
    assert.equal(inputs.length, failsFirst ? 2 : 1);
    if (failsFirst) {
      assert.equal(inputs[1].split('\n').slice(0, -2).join('\n'), preserved);
      assert.match(inputs[1].split('\n').at(-2), /^%%.*Payment processing/);
      assert.equal(inputs[1].split('\n').at(-1), 'Done --> [*]');
    }
    assert.ok(node.querySelector('.mermaid-body svg'));
    assert.equal(node.querySelector('pre code').textContent, source + '\n');
  });
}

for (const succeeds of [false, true]) {
  test(`Mermaid state heading and init recovery ${succeeds ? 'combine successfully' : 'stop with the original source when all candidates fail'}`, async t => {
    const { w, app } = setup(t);
    const source = '%%{init: invalid}%%\nstateDiagram-v2\n-- Ödeme Akışı --\n[*] --> Payment\nPayment --> [*]';
    const calls = [];
    w.mermaid = {
      render: async (_, input, host) => {
        calls.push({ input, host });
        if (!succeeds || input.includes('%%{init:') || input.split('\n').includes('-- Ödeme Akışı --')) {
          throw new Error('Still invalid');
        }
        return { svg: '<svg><text>Payment</text></svg>' };
      },
    };
    const node = app.buildMessageNode({ role: 'assistant', content: '```mermaid\n' + source + '\n```' }, 0);
    await new Promise(resolve => setImmediate(resolve));
    assert.equal(calls[0].input, source);
    assert.ok(calls.length > 1 && calls.length <= 4, 'recovery has a small, fixed attempt limit');
    assert.equal(new Set(calls.map(call => call.input)).size, calls.length, 'do not retry the same source');
    assert.ok(calls.every(call => call.host && !call.host.isConnected));
    assert.equal(node.querySelector('pre code').textContent, source + '\n');
    if (succeeds) {
      assert.ok(node.querySelector('.mermaid-body svg'));
      assert.match(calls.at(-1).input, /^stateDiagram-v2\n%%[^\n]*Ödeme Akışı[^\n]*\n\[\*\] --> Payment\nPayment --> \[\*\]$/);
    } else {
      assert.equal(node.querySelector('.mermaid-body svg'), null);
      assert.match(node.querySelector('[role="alert"]').textContent, /Still invalid/);
      assert.equal(node.querySelector('pre').classList.contains('hidden'), false);
      assert.equal(node.querySelector('.mermaid-copy-btn').disabled, true);
      assert.equal(node.querySelector('.mermaid-zoom-btn').disabled, true);
    }
  });
}

test('Mermaid state heading fallback leaves other diagram grammars unchanged after failure', async t => {
  const { w, app } = setup(t);
  const source = 'sequenceDiagram\nNote over Alice: first line<br/>-- visible note --\n-- Unsupported syntax --\nAlice->>Bob: Message';
  const inputs = [];
  w.mermaid = { render: async (_, input) => { inputs.push(input); throw new Error('Unrelated syntax error'); } };
  const node = app.buildMessageNode({ role: 'assistant', content: '```mermaid\n' + source + '\n```' }, 0);
  await new Promise(resolve => setImmediate(resolve));
  assert.deepEqual(inputs, [source]);
  assert.equal(node.querySelector('pre code').textContent, source + '\n');
  assert.match(node.querySelector('[role="alert"]').textContent, /Unrelated syntax error/);
});

for (const mode of ['rejected promise', 'synchronous throw']) {
  test(`Mermaid ${mode} leaves a readable escaped error, working toggle and no body artifacts`, async t => {
    const { w, app } = setup(t);
    const hosts = [];
    const error = 'Parse error: <img src=x onerror="window.unexpectedMermaidHandler=true">';
    w.mermaid = {
      render(_, input, host) {
        hosts.push(host);
        if (host) {
          const artifact = w.document.createElement('div');
          artifact.className = 'test-mermaid-render-artifact';
          artifact.innerHTML = '<svg><text>Syntax error in text</text></svg>';
          host.appendChild(artifact);
        }
        if (mode === 'synchronous throw') throw new Error(error);
        return Promise.reject(new Error(error));
      },
    };
    const node = app.buildMessageNode({ role: 'assistant', content: '```mermaid\ninvalid diagram\n```' }, 0);
    w.document.getElementById('messagesInner').appendChild(node);
    await new Promise(resolve => setImmediate(resolve));
    const card = node.querySelector('.mermaid-diagram-card');
    const body = card.querySelector('.mermaid-body');
    const source = card.querySelector('pre');
    const toggle = card.querySelector('.mermaid-toggle-btn');
    assert.equal(source.classList.contains('hidden'), false);
    assert.equal(body.classList.contains('hidden'), false, 'failure is readable alongside source');
    assert.match(body.textContent, /Diyagram oluşturulamadı/);
    assert.ok(body.textContent.includes(error));
    assert.equal(body.querySelector('img'), null, 'error content is text, not HTML');
    assert.equal(card.querySelector('.mermaid-copy-btn').disabled, true);
    assert.equal(card.querySelector('.mermaid-zoom-btn').disabled, true);
    assert.ok(hosts.length > 0 && hosts.every(host => host && !host.isConnected));
    assert.equal(w.document.querySelector('.test-mermaid-render-artifact'), null);
    assert.match(toggle.textContent, /Diyagram Görünümü/);
    toggle.click();
    assert.equal(source.classList.contains('hidden'), true, 'one click closes the automatically opened source');
    assert.equal(body.classList.contains('hidden'), false);
    assert.match(toggle.textContent, /Kod Görünümü/);
    toggle.click();
    assert.equal(source.classList.contains('hidden'), false);
  });
}

for (const [label, response] of [
  ['network failure', () => sse([event('Alınan kısım')], 'connection lost')],
  ['server stream error', () => sse([event('Alınan kısım'), 'data: {"error":{"message":"backend failed"}}\n\n'])],
  ['unexpected EOF', () => sse([event('Alınan kısım')])],
  ['token limit', () => sse([event('Alınan kısım', 'length'), 'data: [DONE]\n\n'])],
  ['malformed event', () => sse([event('Alınan kısım'), 'data: {broken}\n\n'])],
]) {
  test(`stream ${label} preserves received text and displays an error`, async t => {
    const { w, app } = setup(t);
    app.history = [{ role: 'user', content: 'Diagram oluştur' }];
    app.streaming = true;
    w.fetch = async () => response();
    await app.generateAssistantReply();
    assert.equal(app.history[1].role, 'assistant');
    assert.equal(app.history[1].content, 'Alınan kısım');
    assert.equal(app.history[2].role, 'error');
    assert.equal(app.savedHistory[1].content, 'Alınan kısım');
    assert.match(w.document.getElementById('messagesInner').textContent, /Alınan kısım/);
    assert.equal(app.busy, false);
    assert.equal(app.controller, null);
  });
}

test('SSE supports split UTF-8, data without a space and an unterminated final line', async t => {
  const { w, app } = setup(t);
  const bytes = new TextEncoder().encode(event('Türkçe: ı ş 🙂').replace('data: ', 'data:') + event(' bitti', 'stop').trimEnd());
  let index = 0;
  w.fetch = async () => new Response(new ReadableStream({ pull(c) { index < bytes.length ? c.enqueue(bytes.slice(index, ++index)) : c.close(); } }),
    { headers: { 'content-type': 'text/event-stream' } });
  const result = await app.callApiStreaming('test', [], () => {});
  assert.equal(result.reply, 'Türkçe: ı ş 🙂 bitti');
});

test('streaming mode accepts a server that returns JSON', async t => {
  const { w, app } = setup(t);
  w.fetch = async () => jsonReply('Normal JSON yanıtı');
  let received;
  const result = await app.callApiStreaming('test', [], text => { received = text; });
  assert.equal(result.reply, received);
  assert.equal(received, 'Normal JSON yanıtı');
});

test('stream callback errors are propagated instead of swallowed', async t => {
  const { w, app } = setup(t);
  w.fetch = async () => sse([event('text', 'stop'), 'data: [DONE]\n\n']);
  await assert.rejects(app.callApiStreaming('test', [], () => { throw new Error('render failure'); }), /render failure/);
  assert.equal(app.controller, null);
});

for (const streaming of [false, true]) {
  test(`timeout remains active during the ${streaming ? 'stream' : 'JSON'} body and is distinct from user stop`, async t => {
    const { w, app } = setup(t);
    let expire;
    let cleared = false;
    const timerId = 12345;
    w.setTimeout = callback => { expire = callback; return timerId; };
    w.clearTimeout = id => { assert.equal(id, timerId); cleared = true; };
    w.fetch = async (_, { signal }) => new Response(new ReadableStream({ start(c) {
      signal.addEventListener('abort', () => c.error(new DOMException('Aborted', 'AbortError')));
    } }), { headers: { 'content-type': streaming ? 'text/event-stream' : 'application/json' } });
    const pending = streaming ? app.callApiStreaming('test', [], () => {}) : app.callApi('test', []);
    await new Promise(resolve => setImmediate(resolve));
    assert.equal(cleared, false);
    expire();
    await assert.rejects(pending, /zaman aşımına uğradı/);
    assert.equal(app.stopped, false);
    assert.equal(app.controller, null);
    assert.equal(cleared, true);
  });

  test(`invalid request template releases the ${streaming ? 'stream' : 'JSON'} controller and timer`, async t => {
    const { w, app } = setup(t);
    let cleared = false;
    w.setTimeout = () => 12345;
    w.clearTimeout = () => { cleared = true; };
    app.config.bodyTemplate = '{invalid';
    const pending = streaming ? app.callApiStreaming('test', [], () => {}) : app.callApi('test', []);
    await assert.rejects(pending, /geçerli JSON/);
    assert.equal(app.controller, null);
    assert.equal(cleared, true);
  });

  test(`stop remains available while reading the ${streaming ? 'stream' : 'JSON'} body`, async t => {
    const { w, app } = setup(t);
    let bodyReady;
    const ready = new Promise(resolve => { bodyReady = resolve; });
    w.fetch = async (_, { signal }) => new Response(new ReadableStream({ start(c) {
      signal.addEventListener('abort', () => c.error(new DOMException('Aborted', 'AbortError')));
      bodyReady();
    } }), { headers: { 'content-type': streaming ? 'text/event-stream' : 'application/json' } });
    const pending = streaming ? app.callApiStreaming('test', [], () => {}) : app.callApi('test', []);
    await ready;
    await new Promise(resolve => setImmediate(resolve));
    assert.ok(app.controller);
    app.stopGeneration();
    await assert.rejects(pending, /kullanıcı tarafından durduruldu/);
    assert.equal(app.controller, null);
  });
}
