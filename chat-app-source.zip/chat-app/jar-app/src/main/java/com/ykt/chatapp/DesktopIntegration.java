package com.ykt.chatapp;

import java.awt.AWTException;
import java.awt.Color;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.MenuItem;
import java.awt.PopupMenu;
import java.awt.RenderingHints;
import java.awt.SystemTray;
import java.awt.TrayIcon;
import java.awt.image.BufferedImage;
import java.io.InputStream;

import javax.imageio.ImageIO;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.boot.web.server.context.WebServerApplicationContext;
import org.springframework.context.ApplicationContext;
import org.springframework.context.event.ContextClosedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

/**
 * Sunucu hazır olduğunda tarayıcıyı açar ve sistem tepsisine "Paneli Aç / Çıkış" menüsü ekler.
 * Konsol penceresi olmadığından uygulama buradan kapatılır.
 */
@Component
class DesktopIntegration {

	private static final Logger log = LoggerFactory.getLogger(DesktopIntegration.class);

	private final ApplicationContext context;
	private final boolean enabled;
	private final boolean openBrowser;
	private TrayIcon trayIcon;

	DesktopIntegration(ApplicationContext context,
			@Value("${chatapp.desktop.enabled:true}") boolean enabled,
			@Value("${chatapp.desktop.open-browser:true}") boolean openBrowser) {
		this.context = context;
		this.enabled = enabled;
		this.openBrowser = openBrowser;
	}

	@EventListener(ApplicationReadyEvent.class)
	void onReady() {
		if (!enabled) {
			return;
		}
		String url = ChatAppApplication.appUrl(resolvePort());
		log.info("AI Sohbet Paneli hazır: {}", url);
		installTray(url);
		if (openBrowser) {
			BrowserLauncher.open(url);
		}
	}

	@EventListener(ContextClosedEvent.class)
	void onClose() {
		if (trayIcon != null && SystemTray.isSupported()) {
			SystemTray.getSystemTray().remove(trayIcon);
			trayIcon = null;
		}
	}

	private int resolvePort() {
		if (context instanceof WebServerApplicationContext web && web.getWebServer() != null) {
			return web.getWebServer().getPort();
		}
		return ChatAppApplication.DEFAULT_PORT;
	}

	private void installTray(String url) {
		if (!SystemTray.isSupported()) {
			log.info("Sistem tepsisi desteklenmiyor; tepsi ikonu atlandı.");
			return;
		}
		PopupMenu menu = new PopupMenu();
		MenuItem open = new MenuItem("Paneli Aç");
		open.addActionListener(e -> BrowserLauncher.open(url));
		MenuItem exit = new MenuItem("Çıkış");
		exit.addActionListener(e -> shutdown());
		menu.add(open);
		menu.addSeparator();
		menu.add(exit);

		trayIcon = new TrayIcon(loadIcon(), "AI Sohbet Paneli — " + url, menu);
		trayIcon.setImageAutoSize(true);
		trayIcon.addActionListener(e -> BrowserLauncher.open(url)); // çift tıklama
		try {
			SystemTray.getSystemTray().add(trayIcon);
		} catch (AWTException e) {
			log.warn("Tepsi ikonu eklenemedi: {}", e.getMessage());
			trayIcon = null;
		}
	}

	private void shutdown() {
		new Thread(() -> System.exit(SpringApplication.exit(context, () -> 0)), "chat-app-shutdown").start();
	}

	private Image loadIcon() {
		try (InputStream in = getClass().getResourceAsStream("/icon.png")) {
			if (in != null) {
				return ImageIO.read(in);
			}
		} catch (Exception e) {
			log.debug("icon.png okunamadı, çizilen ikon kullanılacak", e);
		}
		return drawFallbackIcon();
	}

	/** icon.png yoksa basit bir degrade "AI" ikonu çizer. */
	private static Image drawFallbackIcon() {
		int s = 64;
		BufferedImage img = new BufferedImage(s, s, BufferedImage.TYPE_INT_ARGB);
		Graphics2D g = img.createGraphics();
		g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
		g.setPaint(new GradientPaint(0, 0, new Color(0x4F46E5), s, s, new Color(0x06B6D4)));
		g.fillRoundRect(0, 0, s, s, 18, 18);
		g.setColor(Color.WHITE);
		g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 28));
		String text = "AI";
		int w = g.getFontMetrics().stringWidth(text);
		g.drawString(text, (s - w) / 2, s / 2 + 10);
		g.dispose();
		return img;
	}
}
