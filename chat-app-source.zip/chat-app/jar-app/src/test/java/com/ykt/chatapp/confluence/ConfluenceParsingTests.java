package com.ykt.chatapp.confluence;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Base64;

import org.junit.jupiter.api.Test;

class ConfluenceParsingTests {

	static final String BASE = "https://sdlc.yapikredi.com.tr/confluence";

	@Test
	void parsesViewPageActionLink() {
		var ref = ConfluenceLinkParser.parse(BASE + "/pages/viewpage.action?pageId=123456#Baslik", BASE);
		assertEquals("123456", ref.pageId());
	}

	@Test
	void parsesSpacesPagesLink() {
		var ref = ConfluenceLinkParser.parse(BASE + "/spaces/KRD/pages/987654/Kredi+Surecleri", BASE);
		assertEquals("987654", ref.pageId());
	}

	@Test
	void parsesDisplayLinkWithTurkishTitle() {
		var ref = ConfluenceLinkParser.parse(BASE + "/display/KRD/Ta%C5%9F%C4%B1t+Kredisi+S%C3%BCreci", BASE);
		assertNull(ref.pageId());
		assertEquals("KRD", ref.spaceKey());
		assertEquals("Taşıt Kredisi Süreci", ref.title());
	}

	@Test
	void parsesTinyLinkRoundTrip() {
		for (long id : new long[] { 65538L, 123456789L, 2_147_483_999L }) {
			var ref = ConfluenceLinkParser.parse(BASE + "/x/" + encodeTiny(id), BASE);
			assertEquals(String.valueOf(id), ref.pageId(), "tiny link for " + id);
		}
	}

	@Test
	void rejectsOtherHosts() {
		assertNull(ConfluenceLinkParser.parse("https://evil.example.com/confluence/pages/viewpage.action?pageId=1", BASE));
		assertNull(ConfluenceLinkParser.parse(BASE + "/dashboard.action", BASE));
	}

	@Test
	void convertsStorageFormatPreservingStructure() {
		String storage = "<h2>Vade&nbsp;Sınırları</h2><p>Taşıt kredisinde <strong>azami</strong> vade:</p>"
				+ "<ul><li>Sıfır araç: 48 ay</li><li>İkinci el: 36 ay</li></ul>"
				+ "<table><tbody><tr><th>Tutar</th><th>Kefil</th></tr><tr><td>&lt; 500.000 TL</td><td>Gerekmez</td></tr></tbody></table>"
				+ "<ac:structured-macro ac:name=\"code\"><ac:parameter ac:name=\"language\">sql</ac:parameter>"
				+ "<ac:plain-text-body><![CDATA[SELECT * FROM KREDI\nWHERE VADE > 36]]></ac:plain-text-body></ac:structured-macro>"
				+ "<ac:image><ri:attachment ri:filename=\"diagram.png\"/></ac:image>";
		String text = StorageFormatConverter.toText(storage);

		assertTrue(text.contains("## Vade Sınırları"), text);
		assertTrue(text.contains("Taşıt kredisinde azami vade:"), text);
		assertTrue(text.contains("- Sıfır araç: 48 ay"), text);
		assertTrue(text.contains("| Tutar | Kefil"), text);
		assertTrue(text.contains("| < 500.000 TL | Gerekmez"), text);
		assertTrue(text.contains("SELECT * FROM KREDI\nWHERE VADE > 36"), text);
		assertFalse(text.contains("diagram.png"), text);
		assertFalse(text.contains("sql\n"), "makro parametresi metne girmemeli: " + text);
	}

	@Test
	void extractsKeywordsWithoutStopwords() {
		assertEquals(java.util.List.of("taşıt", "kredisinde", "kefil", "şartı", "aranıyor"),
				ConfluenceClient.keywords("Taşıt kredisinde kefil şartı aranıyor mu?"));
	}

	/** Confluence'ın kısa link üretimi: id → LE baytlar → base64, sondaki '=' ve 'A' kırpılır. */
	private static String encodeTiny(long id) {
		byte[] bytes = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(id).array();
		String s = Base64.getEncoder().encodeToString(bytes).replaceAll("=+$", "").replaceAll("A+$", "");
		return s.replace('/', '-').replace('+', '_');
	}
}
