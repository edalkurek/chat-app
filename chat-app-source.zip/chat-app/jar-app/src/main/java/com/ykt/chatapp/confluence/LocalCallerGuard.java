package com.ykt.chatapp.confluence;

import java.net.URI;
import java.util.Set;

import org.springframework.http.HttpHeaders;

import jakarta.servlet.http.HttpServletRequest;

/**
 * Token sunucuda tutulduğu için Confluence uçlarını yalnızca bu uygulamanın kendi sayfası kullanabilmeli:
 * <ul>
 * <li>Host başlığı yerel olmalı (DNS rebinding koruması)</li>
 * <li>Origin varsa uygulamanın kendi origin'i olmalı (başka sitelerin istek atmasını engeller)</li>
 * </ul>
 */
final class LocalCallerGuard {

	private static final Set<String> LOCAL_HOSTS = Set.of("127.0.0.1", "localhost", "[::1]", "::1");

	private LocalCallerGuard() {
	}

	/** @return reddetme nedeni; istek kabul edilebilirse {@code null} */
	static String reject(HttpServletRequest request) {
		String host = hostOnly(request.getHeader(HttpHeaders.HOST));
		if (host == null || !LOCAL_HOSTS.contains(host)) {
			return "Geçersiz Host";
		}
		String origin = request.getHeader(HttpHeaders.ORIGIN);
		if (origin != null) {
			try {
				URI o = URI.create(origin);
				if (o.getHost() == null || !LOCAL_HOSTS.contains(o.getHost().toLowerCase())
						|| o.getPort() != request.getLocalPort()) {
					return "Bu uç yalnızca AI Sohbet Paneli tarafından kullanılabilir";
				}
			} catch (IllegalArgumentException e) {
				return "Geçersiz Origin";
			}
		}
		return null;
	}

	static String rejectMutation(HttpServletRequest request) {
		String rejection = reject(request);
		if (rejection != null) {
			return rejection;
		}
		if (request.getHeader(HttpHeaders.ORIGIN) == null
				|| !"1".equals(request.getHeader("X-ChatApp-Request"))) {
			return "Değişiklik yalnızca uygulama arayüzünden yapılabilir";
		}
		return null;
	}

	private static String hostOnly(String hostHeader) {
		if (hostHeader == null) {
			return null;
		}
		if (hostHeader.startsWith("[")) {
			int end = hostHeader.indexOf(']');
			return end > 0 ? hostHeader.substring(0, end + 1) : hostHeader;
		}
		int colon = hostHeader.indexOf(':');
		return (colon >= 0 ? hostHeader.substring(0, colon) : hostHeader).toLowerCase();
	}
}
