/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./chat-app.html"],
  darkMode: 'class',
  theme: {
    extend: {
      fontFamily: {
        sans: ['"Plus Jakarta Sans"', 'ui-sans-serif', 'system-ui', '-apple-system', 'BlinkMacSystemFont', '"Segoe UI"', 'Roboto', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'ui-monospace', 'SFMono-Regular', 'Menlo', 'Monaco', 'Consolas', 'monospace'],
      },
      colors: {
        base: '#090d16',
        panel: '#0f172a',
        panel2: '#162032',
        panel3: '#1e293b',
        border: '#1e293b',
        borderSubtle: '#2a3854',
        accent: '#2563eb',
        accentHover: '#1d4ed8',
        ykBlue: '#002d72',
        ykCyan: '#00a3e0',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0', transform: 'translateY(6px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        pulseGlow: {
          '0%, 100%': { opacity: '0.6', transform: 'scale(1)' },
          '50%': { opacity: '1', transform: 'scale(1.05)' },
        },
        shimmer: {
          '0%': { backgroundPosition: '-200% 0' },
          '100%': { backgroundPosition: '200% 0' },
        },
        blink: {
          '0%, 80%, 100%': { opacity: '0.2', transform: 'scale(0.85)' },
          '40%': { opacity: '1', transform: 'scale(1.15)' },
        },
      },
      animation: {
        fadeIn: 'fadeIn 0.25s cubic-bezier(0.16, 1, 0.3, 1)',
        pulseGlow: 'pulseGlow 2.5s infinite ease-in-out',
        shimmer: 'shimmer 2s infinite linear',
      },
    },
  },
}
