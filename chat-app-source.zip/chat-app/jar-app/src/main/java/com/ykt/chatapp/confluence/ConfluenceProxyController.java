package com.ykt.chatapp.confluence;

import java.io.IOException;
import java.net.ConnectException;
import java.net.URI;
import java.net.UnknownHostException;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpTimeoutException;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.Set;

import javax.net.ssl.SSLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.servlet.http.HttpServletRequest;

/**
 * Tarayıcı → 127.0.0.1:17860/api/confluence/** → Confluence Data Center.
 * <p>
 * İstek tarayıcıdan değil sunucudan gittiği için CORS uygulanmaz. Örnek:
 * <pre>fetch('/api/confluence/rest/api/content/search?cql=' + encodeURIComponent('text ~ "kredi"'))</pre>
 */
@RestController
class ConfluenceProxyController {

	private static final Logger log = LoggerFactory.getLogger(ConfluenceProxyController.class);
	static final String PREFIX = "/api/confluence";

	/** Upstream'e aktarılan istemci başlıkları (Host, Cookie vb. bilerek aktarılmaz). */
	private static final Set<String> FORWARDED_REQUEST_HEADERS = Set.of(
			"accept", "accept-language", "content-type", "x-atlassian-token");
	private static final Set<String> FORWARDED_RESPONSE_HEADERS = Set.of(
			"content-type", "content-disposition", "etag", "last-modified");

	private final ConfluenceClient confluence;
	private final ConfluenceProperties props;

	ConfluenceProxyController(ConfluenceClient confluence) {
		this.confluence = confluence;
		this.props = confluence.props;
		log.info("Confluence proxy: {} -> {}", PREFIX, props.baseUrl());
	}

	/** Arayüzün bağlantı durumunu göstermesi için: token var mı, hedef adres ne. */
	@GetMapping(PREFIX + "-status")
	Map<String, Object> status() {
		return Map.of("baseUrl", props.baseUrl(), "tokenConfigured", confluence.hasToken());
	}

	@GetMapping(PREFIX + "/**")
	ResponseEntity<byte[]> proxy(HttpServletRequest request) throws IOException {
		String rejection = LocalCallerGuard.reject(request);
		if (rejection != null) {
			return error(HttpStatus.FORBIDDEN, rejection);
		}

		String path = request.getRequestURI().substring(request.getContextPath().length() + PREFIX.length());
		String query = request.getQueryString();
		URI target = URI.create(props.baseUrl() + path + (query == null ? "" : "?" + query));

		HttpRequest.Builder upstream = HttpRequest.newBuilder(target).timeout(props.timeout());
		for (String name : FORWARDED_REQUEST_HEADERS) {
			String value = request.getHeader(name);
			if (value != null && !value.isBlank()) {
				upstream.header(name, value);
			}
		}
		String auth = confluence.authorization();
		if (auth != null) {
			upstream.header(HttpHeaders.AUTHORIZATION, auth);
		}
		if (request.getHeader(HttpHeaders.ACCEPT) == null) {
			upstream.header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
		}
		upstream.GET();

		try {
			HttpResponse<byte[]> response = confluence.http.send(upstream.build(),
					HttpResponse.BodyHandlers.ofByteArray());
			HttpHeaders headers = new HttpHeaders();
			response.headers().map().forEach((name, values) -> {
				if (FORWARDED_RESPONSE_HEADERS.contains(name.toLowerCase())) {
					headers.put(name, values);
				}
			});
			log.debug("Confluence GET {} -> {}", target, response.statusCode());
			return ResponseEntity.status(response.statusCode()).headers(headers).body(response.body());
		} catch (HttpTimeoutException e) {
			return error(HttpStatus.GATEWAY_TIMEOUT, "Confluence zaman aşımına uğradı: " + target.getHost());
		} catch (SSLException e) {
			log.warn("Confluence TLS hatası", e);
			return error(HttpStatus.BAD_GATEWAY, "Confluence sertifikası doğrulanamadı: " + e.getMessage());
		} catch (ConnectException | UnknownHostException e) {
			return error(HttpStatus.BAD_GATEWAY,
					"Confluence'a ulaşılamadı (" + target.getHost() + "). Kurum ağına/VPN'e bağlı olduğunuzdan emin olun.");
		} catch (IOException e) {
			log.warn("Confluence isteği başarısız: {}", target, e);
			return error(HttpStatus.BAD_GATEWAY, "Confluence isteği başarısız: " + e.getMessage());
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
			return error(HttpStatus.SERVICE_UNAVAILABLE, "İstek iptal edildi");
		}
	}

	private static ResponseEntity<byte[]> error(HttpStatus status, String message) {
		String json = "{\"error\":" + jsonString(message) + "}";
		return ResponseEntity.status(status).contentType(MediaType.APPLICATION_JSON)
				.body(json.getBytes(StandardCharsets.UTF_8));
	}

	private static String jsonString(String s) {
		return '"' + s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", " ") + '"';
	}
}
