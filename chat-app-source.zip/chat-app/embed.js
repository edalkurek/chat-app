const fs = require('fs');
let css = fs.readFileSync('output.css', 'utf8');
let html = fs.readFileSync('chat-app.html', 'utf8');
let regex = /<style>\s*\/\*! tailwindcss v4\.3\.3[\s\S]*?<\/style>/;
html = html.replace(regex, '<style>\n' + css + '\n</style>');
fs.writeFileSync('chat-app.html', html);
