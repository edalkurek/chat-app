package com.ykt.chatapp.confluence;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.net.InetSocketAddress;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicReference;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;

import com.sun.net.httpserver.HttpServer;

/** Sahte bir Confluence (JDK HttpServer, context path /confluence) ile proxy davranışını doğrular. */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
		properties = { "chatapp.desktop.enabled=false", "chatapp.confluence.token=test-pat" })
class ConfluenceProxyControllerTests {

	static HttpServer fakeConfluence;
	static final AtomicReference<String> lastUri = new AtomicReference<>();
	static final AtomicReference<String> lastAuth = new AtomicReference<>();
	static final AtomicReference<String> lastMethod = new AtomicReference<>();
	static final AtomicReference<String> lastXsrf = new AtomicReference<>();
	static final AtomicReference<String> lastBody = new AtomicReference<>();
	static final Path tokenFile = Path.of(System.getProperty("java.io.tmpdir"), "chatapp-test-pat-" + UUID.randomUUID());

	static final String PAGE_JSON = "{\"id\":\"4242\",\"type\":\"page\",\"title\":\"Taşıt Kredisi\","
			+ "\"space\":{\"key\":\"KRD\",\"name\":\"Krediler\"},"
			+ "\"body\":{\"storage\":{\"value\":\"<h1>Kefil</h1><p>500.000 TL altı kefil aranmaz.</p>\",\"representation\":\"storage\"}},"
			+ "\"_links\":{\"webui\":\"/display/KRD/Ta%C5%9F%C4%B1t+Kredisi\"},\"version\":{\"number\":3}}";

	@BeforeAll
	static void startFake() throws Exception {
		fakeConfluence = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
		fakeConfluence.createContext("/confluence/", exchange -> {
			lastUri.set(exchange.getRequestURI().toString());
			lastAuth.set(exchange.getRequestHeaders().getFirst("Authorization"));
			lastMethod.set(exchange.getRequestMethod());
			lastXsrf.set(exchange.getRequestHeaders().getFirst("X-Atlassian-Token"));
			lastBody.set(new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8));
			String path = exchange.getRequestURI().getPath();
			String rawQuery = exchange.getRequestURI().getRawQuery();
			String query = rawQuery == null ? "" : java.net.URLDecoder.decode(rawQuery, StandardCharsets.UTF_8);
			String json;
			int status = 200;
			if (path.equals("/confluence/rest/api/user/current")) {
				json = "{\"displayName\":\"Test Kullanıcı\",\"username\":\"tester\"}";
			} else if (path.equals("/confluence/rest/api/content/4242")) {
				json = PAGE_JSON;
			} else if (path.equals("/confluence/rest/api/content/404")) {
				status = 404;
				json = "{}";
			} else if (path.equals("/confluence/rest/api/content") && "POST".equals(exchange.getRequestMethod())) {
				status = 201;
				json = PAGE_JSON;
			} else if (path.equals("/confluence/rest/api/content")) {
				json = "{\"results\":[" + PAGE_JSON + "]}";
			} else if (path.equals("/confluence/rest/api/content/search") && query.contains(" OR ")) {
				json = "{\"results\":[" + PAGE_JSON + "]}"; // OR geri dönüşü sonuç bulur
			} else if (path.equals("/confluence/rest/api/content/search") && query.contains("text ~ \"taşıt kefil\"")) {
				json = "{\"results\":[]}"; // birlikte arama sonuç vermez
			} else {
				json = "{\"results\":[{\"title\":\"Kredi Süreçleri\"}]}";
			}
			byte[] body = json.getBytes(StandardCharsets.UTF_8);
			exchange.getResponseHeaders().add("Content-Type", "application/json;charset=UTF-8");
			exchange.sendResponseHeaders(status, body.length);
			exchange.getResponseBody().write(body);
			exchange.close();
		});
		fakeConfluence.start();
	}

	@AfterAll
	static void stopFake() throws Exception {
		fakeConfluence.stop(0);
		Files.deleteIfExists(tokenFile);
	}

	@DynamicPropertySource
	static void props(DynamicPropertyRegistry registry) {
		registry.add("chatapp.confluence.base-url",
				() -> "http://127.0.0.1:" + fakeConfluence.getAddress().getPort() + "/confluence/");
		registry.add("chatapp.confluence.token-file", () -> tokenFile.toString());
	}

	@Autowired
	Environment env;

	private final HttpClient client = HttpClient.newHttpClient();

	@Test
	void requestAndResponseDebugStringsHideSecretsAndPageContent() {
		assertTrue(!new ConfluenceEditorController.TokenInput("private-pat").toString().contains("private-pat"));
		assertTrue(!new ConfluenceEditorController.CreatePageInput("KRD", "Title", "private-body")
				.toString().contains("private-body"));
		assertTrue(!new ConfluenceEditorController.UpdatePageInput("Title", "private-storage", 1)
				.toString().contains("private-storage"));
		assertTrue(!new ConfluenceClient.EditablePage("42", "Title", "KRD", "url", "private-storage", 1)
				.toString().contains("private-storage"));
		assertTrue(!new ConfluenceClient.PageText("42", "Title", "KRD", "Space", "url", "private-body", false)
				.toString().contains("private-body"));
	}

	private URI local(String path) {
		return URI.create("http://127.0.0.1:" + env.getProperty("local.server.port") + path);
	}

	@Test
	void forwardsPathQueryAndInjectsServerToken() throws Exception {
		String cql = "cql=text%20~%20%22kredi%22&limit=5";
		HttpResponse<String> res = client.send(
				HttpRequest.newBuilder(local("/api/confluence/rest/api/content/search?" + cql)).build(),
				HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));

		assertEquals(200, res.statusCode());
		assertTrue(res.body().contains("Kredi Süreçleri"));
		assertTrue(res.headers().firstValue("Content-Type").orElse("").startsWith("application/json"));
		assertEquals("/confluence/rest/api/content/search?" + cql, lastUri.get());
		assertEquals("Bearer test-pat", lastAuth.get());
	}

	@Test
	void browserAuthorizationCannotOverrideServerPat() throws Exception {
		client.send(HttpRequest.newBuilder(local("/api/confluence/rest/api/space"))
				.header("Authorization", "Bearer user-pat").build(), HttpResponse.BodyHandlers.discarding());
		assertEquals("Bearer test-pat", lastAuth.get());
	}

	@Test
	void genericProxyRejectsWriteRequests() throws Exception {
		HttpResponse<String> res = client.send(HttpRequest.newBuilder(local("/api/confluence/rest/api/content"))
				.header("Content-Type", "application/json")
				.POST(HttpRequest.BodyPublishers.ofString("{}")).build(), HttpResponse.BodyHandlers.ofString());
		assertEquals(405, res.statusCode());
	}

	@Test
	void rejectsForeignOrigin() throws Exception {
		HttpResponse<String> res = client.send(HttpRequest.newBuilder(local("/api/confluence/rest/api/space"))
				.header("Origin", "https://evil.example.com").build(), HttpResponse.BodyHandlers.ofString());
		assertEquals(403, res.statusCode());
	}

	@Test
	void allowsOwnOrigin() throws Exception {
		String port = env.getProperty("local.server.port");
		HttpResponse<String> res = client.send(HttpRequest.newBuilder(local("/api/confluence/rest/api/space"))
				.header("Origin", "http://127.0.0.1:" + port).build(), HttpResponse.BodyHandlers.ofString());
		assertEquals(200, res.statusCode());
	}

	@Test
	void statusEndpointReportsConfig() throws Exception {
		HttpResponse<String> res = client.send(HttpRequest.newBuilder(local("/api/confluence-status")).build(),
				HttpResponse.BodyHandlers.ofString());
		assertEquals(200, res.statusCode());
		assertTrue(res.body().contains("\"tokenConfigured\":true"));
		assertTrue(res.body().contains("/confluence\""), "Sondaki / kırpılmalı: " + res.body());
	}

	private HttpRequest.Builder mutation(String path) {
		String port = env.getProperty("local.server.port");
		return HttpRequest.newBuilder(local(path))
				.header("Origin", "http://127.0.0.1:" + port)
				.header("X-ChatApp-Request", "1")
				.header("Content-Type", "application/json");
	}

	@Test
	void patCanBeSavedAndConnectionTestedWithoutReturningSecret() throws Exception {
		try {
			HttpResponse<String> saved = client.send(mutation("/api/confluence-token")
					.PUT(HttpRequest.BodyPublishers.ofString("{\"pat\":\"replacement-pat\"}"))
					.build(), HttpResponse.BodyHandlers.ofString());
			assertEquals(200, saved.statusCode(), saved.body());
			assertTrue(!saved.body().contains("replacement-pat"));
			HttpResponse<String> connection = getLocal("/api/confluence-connection");
			assertEquals(200, connection.statusCode(), connection.body());
			assertTrue(connection.body().contains("Test Kullanıcı"));
			assertEquals("Bearer replacement-pat", lastAuth.get());
		} finally {
			client.send(mutation("/api/confluence-token")
					.PUT(HttpRequest.BodyPublishers.ofString("{\"pat\":\"test-pat\"}"))
					.build(), HttpResponse.BodyHandlers.discarding());
		}
	}

	@Test
	void createAndUpdateRequireOwnOriginAndVersion() throws Exception {
		String create = "{\"spaceKey\":\"KRD\",\"title\":\"Yeni Sayfa\",\"text\":\"Merhaba <ekip>\"}";
		HttpResponse<String> forbidden = client.send(HttpRequest.newBuilder(local("/api/confluence-editor/pages"))
				.header("Content-Type", "application/json")
				.POST(HttpRequest.BodyPublishers.ofString(create)).build(), HttpResponse.BodyHandlers.ofString());
		assertEquals(403, forbidden.statusCode());
		HttpResponse<String> created = client.send(mutation("/api/confluence-editor/pages")
				.POST(HttpRequest.BodyPublishers.ofString(create)).build(), HttpResponse.BodyHandlers.ofString());
		assertEquals(200, created.statusCode(), created.body());
		assertEquals("POST", lastMethod.get());
		assertEquals("no-check", lastXsrf.get());
		assertTrue(lastBody.get().contains("&lt;ekip&gt;"), lastBody.get());

		String pageUrl = fakeBase() + "/pages/viewpage.action?pageId=4242";
		HttpResponse<String> loaded = getLocal("/api/confluence-editor/page?url=" + q(pageUrl));
		assertEquals(200, loaded.statusCode(), loaded.body());
		assertTrue(loaded.body().contains("\"version\":3"), loaded.body());
		assertTrue(loaded.body().contains("<h1>Kefil</h1>"), loaded.body());

		String stale = "{\"title\":\"Başlık\",\"storage\":\"<p>Yeni</p>\",\"version\":2}";
		HttpResponse<String> conflict = client.send(mutation("/api/confluence-editor/pages/4242")
				.PUT(HttpRequest.BodyPublishers.ofString(stale)).build(), HttpResponse.BodyHandlers.ofString());
		assertEquals(409, conflict.statusCode(), conflict.body());

		String update = "{\"title\":\"Başlık\",\"storage\":\"<p>Yeni</p>\",\"version\":3}";
		HttpResponse<String> updated = client.send(mutation("/api/confluence-editor/pages/4242")
				.PUT(HttpRequest.BodyPublishers.ofString(update)).build(), HttpResponse.BodyHandlers.ofString());
		assertEquals(200, updated.statusCode(), updated.body());
		assertEquals("PUT", lastMethod.get());
		assertTrue(lastBody.get().contains("\"number\":4"), lastBody.get());
	}

	private String fakeBase() {
		return "http://127.0.0.1:" + fakeConfluence.getAddress().getPort() + "/confluence";
	}

	private HttpResponse<String> getLocal(String pathAndQuery) throws Exception {
		return client.send(HttpRequest.newBuilder(local(pathAndQuery)).build(),
				HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
	}

	private static String q(String s) {
		return java.net.URLEncoder.encode(s, StandardCharsets.UTF_8);
	}

	@Test
	void pageEndpointResolvesViewPageLink() throws Exception {
		HttpResponse<String> res = getLocal("/api/confluence-page?url=" + q(fakeBase() + "/pages/viewpage.action?pageId=4242"));
		assertEquals(200, res.statusCode(), res.body());
		assertTrue(res.body().contains("\"title\":\"Taşıt Kredisi\""), res.body());
		assertTrue(res.body().contains("# Kefil"), res.body());
		assertTrue(res.body().contains("500.000 TL altı kefil aranmaz."), res.body());
		assertTrue(res.body().contains(fakeBase() + "/display/KRD/"), "web adresi mutlak olmalı: " + res.body());
		assertEquals("Bearer test-pat", lastAuth.get());
	}

	@Test
	void pageEndpointResolvesDisplayLinkBySpaceAndTitle() throws Exception {
		HttpResponse<String> res = getLocal("/api/confluence-page?url=" + q(fakeBase() + "/display/KRD/Ta%C5%9F%C4%B1t+Kredisi"));
		assertEquals(200, res.statusCode(), res.body());
		assertTrue(lastUri.get().contains("spaceKey=KRD"), lastUri.get());
		assertTrue(lastUri.get().contains("title=Ta%C5%9F%C4%B1t+Kredisi"), lastUri.get());
	}

	@Test
	void pageEndpointMapsNotFoundAndForeignLinks() throws Exception {
		HttpResponse<String> missing = getLocal("/api/confluence-page?url=" + q(fakeBase() + "/pages/viewpage.action?pageId=404"));
		assertEquals(404, missing.statusCode());
		assertTrue(missing.body().contains("bulunamadı"), missing.body());

		HttpResponse<String> foreign = getLocal("/api/confluence-page?url=" + q("https://example.com/pages/viewpage.action?pageId=1"));
		assertEquals(400, foreign.statusCode());
	}

	@Test
	void searchEndpointFallsBackToOrQuery() throws Exception {
		HttpResponse<String> res = getLocal("/api/confluence-search?limit=3&q=" + q("Taşıt kefil nedir?"));
		assertEquals(200, res.statusCode(), res.body());
		assertTrue(res.body().contains("\"title\":\"Taşıt Kredisi\""), res.body());
		assertTrue(lastUri.get().contains("limit=3"), lastUri.get());
	}

	@Test
	void contextEndpointsRejectForeignOrigin() throws Exception {
		HttpResponse<String> res = client.send(HttpRequest.newBuilder(local("/api/confluence-search?q=kredi"))
				.header("Origin", "https://evil.example.com").build(), HttpResponse.BodyHandlers.ofString());
		assertEquals(403, res.statusCode());
	}
}
