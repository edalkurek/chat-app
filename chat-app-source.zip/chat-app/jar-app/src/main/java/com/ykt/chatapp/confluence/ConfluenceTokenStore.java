package com.ykt.chatapp.confluence;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.AclEntry;
import java.nio.file.attribute.AclEntryPermission;
import java.nio.file.attribute.AclEntryType;
import java.nio.file.attribute.AclFileAttributeView;
import java.nio.file.attribute.PosixFilePermission;
import java.util.EnumSet;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/** PAT'i tarayici depolamasina koymadan, kullaniciya ozel dosyada tutar. */
@Component
class ConfluenceTokenStore {

	private final Path path;
	private volatile String token;

	ConfluenceTokenStore(@Value("${chatapp.confluence.token-file:}") String configuredPath,
			ConfluenceProperties properties) throws IOException {
		this.path = (configuredPath == null || configuredPath.isBlank()
				? Path.of(System.getProperty("user.home"), ".chat-app", "confluence.pat")
				: Path.of(configuredPath)).toAbsolutePath();
		this.token = Files.exists(path) ? Files.readString(path, StandardCharsets.UTF_8).trim() : properties.token();
	}

	boolean configured() {
		return !token.isBlank();
	}

	String authorization() {
		return configured() ? "Bearer " + token : null;
	}

	synchronized void save(String value) throws IOException {
		String normalized = value == null ? "" : value.trim();
		if (normalized.regionMatches(true, 0, "Bearer ", 0, 7)) {
			normalized = normalized.substring(7).trim();
		}
		if (normalized.isBlank() || normalized.length() > 4096 || normalized.contains("\n") || normalized.contains("\r")) {
			throw new IllegalArgumentException("Geçerli bir Confluence PAT girin.");
		}
		write(normalized);
		token = normalized;
	}

	synchronized void clear() throws IOException {
		// Bos dosya, eski ortam degiskeni/ayar dosyasindaki PAT'in yeniden etkinlesmesini de engeller.
		write("");
		token = "";
	}

	private void write(String value) throws IOException {
		Files.createDirectories(path.getParent());
		Path temporary = Files.createTempFile(path.getParent(), "confluence-pat-", ".tmp");
		try {
			ownerOnly(temporary);
			Files.writeString(temporary, value, StandardCharsets.UTF_8);
			try {
				Files.move(temporary, path, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
			} catch (java.nio.file.AtomicMoveNotSupportedException e) {
				Files.move(temporary, path, StandardCopyOption.REPLACE_EXISTING);
			}
			ownerOnly(path);
		} finally {
			Files.deleteIfExists(temporary);
		}
	}

	private static void ownerOnly(Path file) throws IOException {
		AclFileAttributeView acl = Files.getFileAttributeView(file, AclFileAttributeView.class);
		if (acl != null) {
			var owner = Files.getOwner(file);
			acl.setAcl(List.of(AclEntry.newBuilder()
					.setType(AclEntryType.ALLOW)
					.setPrincipal(owner)
					.setPermissions(EnumSet.allOf(AclEntryPermission.class))
					.build()));
			return;
		}
		if (Files.getFileAttributeView(file, java.nio.file.attribute.PosixFileAttributeView.class) != null) {
			Files.setPosixFilePermissions(file, EnumSet.of(PosixFilePermission.OWNER_READ,
					PosixFilePermission.OWNER_WRITE));
		}
	}
}
