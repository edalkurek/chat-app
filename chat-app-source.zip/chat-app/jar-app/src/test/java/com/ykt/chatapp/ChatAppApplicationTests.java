package com.ykt.chatapp;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
		properties = { "chatapp.desktop.enabled=false", "server.compression.enabled=false" })
class ChatAppApplicationTests {

	@Autowired
	Environment env;

	private final HttpClient client = HttpClient.newHttpClient();

	private HttpResponse<byte[]> get(String path) throws Exception {
		String port = env.getProperty("local.server.port");
		return client.send(HttpRequest.newBuilder(URI.create("http://127.0.0.1:" + port + path)).build(),
				HttpResponse.BodyHandlers.ofByteArray());
	}

	@Test
	void rootServesOriginalHtmlUnchanged() throws Exception {
		HttpResponse<byte[]> response = get("/");
		assertEquals(200, response.statusCode());
		assertTrue(response.headers().firstValue("Content-Type").orElse("").startsWith("text/html"));
		assertTrue(response.headers().firstValue("Cache-Control").orElse("").contains("no-store"));
		assertFalse(response.headers().firstValue("Last-Modified").isPresent());

		byte[] original = Files.readAllBytes(Path.of("..", "chat-app.html"));
		assertArrayEquals(original, response.body(), "Sunulan HTML, kaynak chat-app.html ile birebir aynı olmalı");
		String html = new String(response.body(), StandardCharsets.UTF_8);
		assertFalse(html.contains("id=\"apiEmbeddingPanel\""));
		assertFalse(html.contains("id=\"cfgEmbeddingModel\""));
		assertFalse(html.contains("id=\"reindexKBBtn\""));
	}

	@Test
	void staleConditionalRequestReceivesCurrentHtml() throws Exception {
		String port = env.getProperty("local.server.port");
		for (String path : new String[] { "/", "/chat-app.html" }) {
			HttpRequest request = HttpRequest.newBuilder(URI.create("http://127.0.0.1:" + port + path))
					.header("If-Modified-Since", "Fri, 01 Feb 1980 00:00:00 GMT")
					.build();
			HttpResponse<byte[]> response = client.send(request, HttpResponse.BodyHandlers.ofByteArray());
			assertEquals(200, response.statusCode(), path + " eski tarayıcı önbelleğiyle 304 döndürmemeli");
			assertTrue(response.headers().firstValue("Cache-Control").orElse("").contains("no-store"));
			assertFalse(new String(response.body(), StandardCharsets.UTF_8).contains("id=\"apiEmbeddingTab\""));
		}
	}

	@Test
	void healthEndpointIdentifiesApp() throws Exception {
		HttpResponse<byte[]> response = get("/api/health");
		assertEquals(200, response.statusCode());
		assertTrue(new String(response.body()).contains(ChatAppApplication.HEALTH_MARKER));
	}

	@Test
	void servesVendoredBrowserDependencies() throws Exception {
		for (String file : new String[] { "highlight.min.js", "marked.umd.js", "purify.min.js", "mermaid.min.js",
				"pdf.min.js", "pdf.worker.min.js", "xlsx.full.min.js", "chart.umd.min.js", "jspdf.umd.min.js",
				"jspdf.plugin.autotable.min.js", "mammoth.browser.min.js", "html2canvas.min.js",
				"highlight-github-dark.min.css" }) {
			HttpResponse<byte[]> response = get("/vendor/" + file);
			assertEquals(200, response.statusCode(), file + " sunulabilmeli");
			assertTrue(response.body().length > 100, file + " boş veya eksik olmamalı");
		}
	}
}
