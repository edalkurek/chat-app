# 🤖 Yapı Kredi Teknoloji — AI Sohbet Paneli

## 📝 Proje Tanımı
**Yapı Kredi Teknoloji — AI Sohbet Paneli**, kullanıcıların yapay zeka modelleriyle üretken ve zengin içerikli etkileşim kurmasını sağlayan modern bir web tabanlı arayüzdür. 🌟 Kullanıcı dostu ve yenilikçi tasarımıyla dikkat çeken bu araç; doküman analizi, veri görselleştirme, kod formatlama ve genişletilebilir yapısı sayesinde karmaşık iş akışlarını tek bir platformda kolaylaştırır. 🚀 Arayüz `chat-app.html` dosyasında, çevrimdışı tarayıcı bağımlılıkları ise `vendor/` klasöründe tutulur. ⚡

## ✨ Özellik Tablosu

| 🎯 Özellik Grubu | 💡 Yetenekler ve Açıklamalar |
| :--- | :--- |
| 📄 **Gelişmiş Doküman Analizi** | PDF, Excel (xlsx) ve Word (docx) formatlarındaki dosyaları okuma, işleme ve veri çıkarma yeteneği. |
| 💻 **Zengin Metin ve Kod Yönetimi** | Markdown formatı desteği, gelişmiş sözdizimi vurgulama (syntax highlighting) ve kod bloklarının kolayca kopyalanması. |
| 📊 **Dinamik Veri Görselleştirme** | İhtiyaca yönelik olarak dinamik grafikler (Chart.js) oluşturabilme ve akış şeması/diyagram (Mermaid.js) modellemesi yapabilme. |
| 📤 **Dışa Aktarma ve Çıktı Alma** | Sohbet içeriklerini doğrudan cihazda PDF olarak dışa aktarabilme ve sayfa kesitlerinin ekran görüntüsünü alabilme. |
| 🎨 **Modern ve Dinamik Arayüz** | Karanlık (Dark) 🌙 ve Aydınlık (Light) ☀️ tema seçenekleri, akıcı animasyonlar ve Tailwind CSS ile geliştirilmiş modern tasarım. |
| ⚙️ **Kurumsal Entegrasyon Altyapısı**| RAG (Retrieval-Augmented Generation) 🧠 mimarisine uyumluluk ve özelleştirilebilir API yapılandırma seçenekleri. |
