<#
.SYNOPSIS
  AI Sohbet Paneli'ni gomulu JRE'li, tasinabilir bir Windows uygulamasina paketler.

.DESCRIPTION
  1. mvnw ile Spring Boot fat JAR uretir (chat-app.html degistirilmeden icine kopyalanir)
  2. jlink ile yalnizca gerekli modulleri iceren kucultulmus bir JRE olusturur
  3. jpackage ile ChatApp.exe iceren app-image klasoru olusturur (WiX gerekmez)
  4. Dagitim icin zip'ler ve boyut raporu verir
  (Windows PowerShell 5.1 uyumlulugu icin dosya ASCII tutulmustur.)

.EXAMPLE
  .\build-package.ps1
  .\build-package.ps1 -SkipTests
  .\build-package.ps1 -OutputDirectory dist-updated
#>
param(
  [switch]$SkipTests,
  [string]$AppName = 'ChatApp',
  [string]$OutputDirectory = 'dist'
)

$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot

# ---- JDK araclari (JAVA_HOME oncelikli) ----
$javaHome = if ($env:JAVA_HOME) { $env:JAVA_HOME } else { Split-Path (Split-Path (Get-Command java).Source) }
$jlink    = Join-Path $javaHome 'bin\jlink.exe'
$jpackage = Join-Path $javaHome 'bin\jpackage.exe'
foreach ($tool in $jlink, $jpackage) { if (-not (Test-Path $tool)) { throw "Bulunamadi: $tool (JDK 17+ gerekli)" } }

# Surum pom.xml'den okunur
$version = ([xml](Get-Content pom.xml -Raw -Encoding UTF8)).project.version
Write-Host "==> $AppName $version paketleniyor (JDK: $javaHome)" -ForegroundColor Cyan

# ---- 1. Fat JAR ----
$mvnArgs = @('-B', '-ntp', 'clean', 'package')
if ($SkipTests) { $mvnArgs += '-DskipTests' }
& .\mvnw.cmd @mvnArgs
if ($LASTEXITCODE -ne 0) { throw 'Maven derlemesi basarisiz.' }

$target   = Join-Path $PSScriptRoot 'target'
$inputDir = Join-Path $target 'jpackage-input'
$runtime  = Join-Path $target 'runtime'
$distCandidate = if ([IO.Path]::IsPathRooted($OutputDirectory)) {
  $OutputDirectory
} else {
  Join-Path $PSScriptRoot $OutputDirectory
}
$dist = [IO.Path]::GetFullPath($distCandidate)
$projectRoot = [IO.Path]::GetFullPath($PSScriptRoot + [IO.Path]::DirectorySeparatorChar)
if (-not $dist.StartsWith($projectRoot, [StringComparison]::OrdinalIgnoreCase) -or $dist -eq $PSScriptRoot) {
  throw 'OutputDirectory proje klasorunun icinde guvenli bir alt klasor olmali.'
}

New-Item -ItemType Directory -Force $inputDir | Out-Null
Copy-Item (Join-Path $target 'chat-app.jar') $inputDir -Force
if (Test-Path $dist) { Remove-Item $dist -Recurse -Force }

# ---- 2. Kucultulmus JRE (jlink) ----
# jdeps --print-module-deps ciktisi + TLS (jdk.crypto.ec), JUL (java.logging), XML (logback) guvenlik payi
# jdk.crypto.mscapi: Windows sertifika deposu (kurumsal CA ile imzali sdlc.yapikredi.com.tr icin)
$modules = @(
  'java.base', 'java.compiler', 'java.desktop', 'java.instrument', 'java.logging', 'java.management',
  'java.naming', 'java.net.http', 'java.prefs', 'java.scripting', 'java.security.jgss', 'java.sql',
  'java.xml', 'jdk.crypto.ec', 'jdk.crypto.mscapi', 'jdk.jfr', 'jdk.unsupported'
) -join ','

Write-Host "==> jlink: $modules" -ForegroundColor Cyan
& $jlink --add-modules $modules --output $runtime `
  --strip-debug --no-man-pages --no-header-files --compress=2
if ($LASTEXITCODE -ne 0) { throw 'jlink basarisiz.' }

# ---- 3. Uygulama imaji (jpackage) ----
Write-Host '==> jpackage (app-image)' -ForegroundColor Cyan
& $jpackage --type app-image `
  --name $AppName `
  --app-version $version `
  --vendor 'Yapi Kredi Teknoloji' `
  --description 'AI Sohbet Paneli' `
  --icon (Join-Path $PSScriptRoot 'packaging\icon.ico') `
  --input $inputDir `
  --main-jar 'chat-app.jar' `
  --runtime-image $runtime `
  --java-options '-Xms64m' `
  --java-options '-Xmx512m' `
  --java-options '-XX:+UseSerialGC' `
  --java-options '-XX:TieredStopAtLevel=1' `
  --java-options '-Dfile.encoding=UTF-8' `
  --dest $dist
if ($LASTEXITCODE -ne 0) { throw 'jpackage basarisiz.' }

# ---- 4. Zip + boyut raporu ----
$appDir = Join-Path $dist $AppName
$zip = Join-Path $dist "$AppName-$version-win-x64.zip"
Compress-Archive -Path $appDir -DestinationPath $zip -CompressionLevel Optimal -Force

function Get-SizeMB($path) {
  $item = Get-Item $path
  $bytes = if ($item.PSIsContainer) { (Get-ChildItem $path -Recurse -File | Measure-Object Length -Sum).Sum } else { $item.Length }
  '{0:N1} MB' -f ($bytes / 1MB)
}

Write-Host ''
Write-Host '==> Boyut raporu' -ForegroundColor Green
[pscustomobject][ordered]@{
  'Fat JAR'          = Get-SizeMB (Join-Path $inputDir 'chat-app.jar')
  'Gomulu JRE'       = Get-SizeMB $runtime
  'Uygulama klasoru' = Get-SizeMB $appDir
  'Zip'              = Get-SizeMB $zip
} | Format-List

Write-Host "Calistirmak icin: $appDir\$AppName.exe" -ForegroundColor Green
