package com.ykt.chatapp.confluence;

import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonProperty;

import tools.jackson.databind.json.JsonMapper;

/** Confluence REST API'sine giden tüm çağrılar (proxy ve bağlam uçları ortak kullanır). */
@Component
class ConfluenceClient {

	/** Bir sayfanın LLM'e verilecek hali. */
	record PageText(String id, String title, String spaceKey, String spaceName, String url, String text,
			boolean truncated) {
		@Override
		public String toString() {
			return "PageText[id=" + id + ", text=<redacted>]";
		}
	}

	/** Upstream hata kodunu kullanıcı dostu mesajla taşır. */
	static final class ConfluenceException extends RuntimeException {
		final int status;

		ConfluenceException(int status, String message) {
			super(message);
			this.status = status;
		}
	}

	// ---- REST yanıt modelleri (bilinmeyen alanlar Jackson 3'te varsayılan olarak yok sayılır) ----
	record ContentList(List<Content> results) {
	}

	record Content(String id, String type, String title, Space space, Body body,
			@JsonProperty("_links") Links links, Version version) {
	}

	record Version(int number) {
	}

	record CurrentUser(String displayName, String username) {
	}

	record EditablePage(String id, String title, String spaceKey, String url, String storage, int version) {
		@Override
		public String toString() {
			return "EditablePage[id=" + id + ", storage=<redacted>]";
		}
	}

	record PublishedPage(String id, String title, String url) {
	}

	record Space(String key, String name) {
	}

	record Body(Storage storage) {
	}

	record Storage(String value) {
	}

	record Links(String webui) {
	}

	private static final int MAX_PAGE_CHARS = 40_000;
	private static final String EXPAND = "body.storage,space";
	/** CQL'e gönderilmeyecek Türkçe/İngilizce dolgu kelimeleri. */
	private static final Set<String> STOPWORDS = Set.of(
			"ve", "veya", "ile", "bir", "bu", "şu", "o", "da", "de", "mi", "mı", "mu", "mü", "ne", "nedir", "nasıl",
			"neden", "niçin", "hangi", "için", "gibi", "kadar", "daha", "çok", "en", "ise", "ki", "ya", "olan",
			"olarak", "var", "yok", "midir", "mıdır", "nerede", "kim", "kaç", "the", "and", "or", "for", "what",
			"how", "is", "are", "of", "to", "in", "bana", "beni", "bize", "lütfen", "hakkında", "anlat", "açıkla");

	final ConfluenceProperties props;
	final HttpClient http;
	private final ConfluenceTokenStore tokens;
	private final JsonMapper json = JsonMapper.builder().build();

	ConfluenceClient(ConfluenceProperties props, ConfluenceTokenStore tokens) {
		this.props = props;
		this.tokens = tokens;
		this.http = HttpClient.newBuilder()
				.connectTimeout(props.timeout())
				.followRedirects(HttpClient.Redirect.NORMAL)
				.sslContext(CorporateTrust.sslContext())
				.build();
	}

	String authorization() {
		return tokens.authorization();
	}

	boolean hasToken() {
		return tokens.configured();
	}

	CurrentUser currentUser() throws IOException, InterruptedException {
		return getJson("/rest/api/user/current", CurrentUser.class);
	}

	PageText fetchPageByLink(String link) throws IOException, InterruptedException {
		return toPageText(fetchContentByLink(link), MAX_PAGE_CHARS);
	}

	EditablePage fetchEditablePage(String link) throws IOException, InterruptedException {
		Content content = fetchContentByLink(link);
		if (!"page".equals(content.type()) || content.version() == null || content.version().number() < 1) {
			throw new ConfluenceException(400, "Bu içerik düzenlenebilir bir Confluence sayfası değil.");
		}
		return new EditablePage(content.id(), content.title(), content.space() == null ? "" : content.space().key(),
				pageUrl(content), content.body() != null && content.body().storage() != null
						? content.body().storage().value() : "", content.version().number());
	}

	private Content fetchContentByLink(String link) throws IOException, InterruptedException {
		ConfluenceLinkParser.PageRef ref = ConfluenceLinkParser.parse(link, props.baseUrl());
		if (ref == null) {
			throw new ConfluenceException(400, "Link bir Confluence sayfası olarak tanınmadı: " + link);
		}
		Content content;
		if (ref.pageId() != null) {
			content = getJson("/rest/api/content/" + ref.pageId() + "?expand=" + EXPAND + ",version", Content.class);
		} else {
			ContentList list = getJson("/rest/api/content?type=page&spaceKey=" + enc(ref.spaceKey()) + "&title="
					+ enc(ref.title()) + "&expand=" + EXPAND + ",version", ContentList.class);
			if (list.results() == null || list.results().isEmpty()) {
				throw new ConfluenceException(404, "Sayfa bulunamadı: " + ref.spaceKey() + " / " + ref.title());
			}
			content = list.results().get(0);
		}
		return content;
	}

	PublishedPage createPage(String spaceKey, String title, String text) throws IOException, InterruptedException {
		if (spaceKey == null || !spaceKey.trim().matches("[A-Za-z0-9_~-]{1,255}")) {
			throw new ConfluenceException(400, "Geçerli bir Confluence alan anahtarı girin.");
		}
		validateTitle(title);
		if (text == null || text.isBlank() || text.length() > 100_000) {
			throw new ConfluenceException(400, "Sayfa içeriği 1-100000 karakter olmalı.");
		}
		Map<String, Object> body = Map.of("type", "page", "title", title.trim(),
				"space", Map.of("key", spaceKey.trim()),
				"body", Map.of("storage", Map.of("value", plainTextToStorage(text), "representation", "storage")));
		Content created = sendJson("POST", "/rest/api/content", body, Content.class);
		return new PublishedPage(created.id(), created.title(), pageUrl(created));
	}

	PublishedPage updatePage(String id, String title, String storage, int expectedVersion)
			throws IOException, InterruptedException {
		if (id == null || !id.matches("[0-9]{1,20}")) {
			throw new ConfluenceException(400, "Geçersiz sayfa kimliği.");
		}
		validateTitle(title);
		if (storage == null || storage.isBlank() || storage.length() > 200_000 || expectedVersion < 1) {
			throw new ConfluenceException(400, "Geçersiz sayfa içeriği veya sürümü.");
		}
		Content current = getJson("/rest/api/content/" + id + "?expand=version", Content.class);
		if (!"page".equals(current.type()) || current.version() == null
				|| current.version().number() != expectedVersion) {
			throw new ConfluenceException(409, "Sayfa siz düzenlerken değişti. Yeniden yükleyip gözden geçirin.");
		}
		Map<String, Object> body = Map.of("id", id, "type", "page", "title", title.trim(),
				"version", Map.of("number", expectedVersion + 1),
				"body", Map.of("storage", Map.of("value", storage, "representation", "storage")));
		Content updated = sendJson("PUT", "/rest/api/content/" + id, body, Content.class);
		return new PublishedPage(updated.id(), updated.title(), pageUrl(updated));
	}

	private static void validateTitle(String title) {
		if (title == null || title.isBlank() || title.trim().length() > 255) {
			throw new ConfluenceException(400, "Sayfa başlığı 1-255 karakter olmalı.");
		}
	}

	private static String plainTextToStorage(String text) {
		String escaped = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
				.replace("\"", "&quot;");
		return "<p>" + escaped.replace("\r\n", "\n").replace("\r", "\n").replace("\n", "<br />") + "</p>";
	}

	/**
	 * Soru metninden anahtar kelimeleri çıkarıp CQL ile arar. Önce tüm kelimeleri birlikte, sonuç yoksa
	 * herhangi birini içeren sayfaları arar. Sıralama Confluence alaka puanına göredir.
	 */
	List<PageText> search(String question, int limit) throws IOException, InterruptedException {
		List<String> terms = keywords(question);
		if (terms.isEmpty()) {
			return List.of();
		}
		String all = "type = page AND text ~ \"" + cqlEscape(String.join(" ", terms)) + "\"";
		List<PageText> pages = runCql(all, limit);
		if (pages.isEmpty() && terms.size() > 1) {
			List<String> ors = terms.stream().map(t -> "text ~ \"" + cqlEscape(t) + "\"").toList();
			pages = runCql("type = page AND (" + String.join(" OR ", ors) + ")", limit);
		}
		return pages;
	}

	private List<PageText> runCql(String cql, int limit) throws IOException, InterruptedException {
		ContentList list = getJson("/rest/api/content/search?cql=" + enc(cql) + "&limit=" + limit + "&expand=" + EXPAND,
				ContentList.class);
		List<PageText> pages = new ArrayList<>();
		if (list.results() != null) {
			for (Content c : list.results()) {
				pages.add(toPageText(c, MAX_PAGE_CHARS / 2));
			}
		}
		return pages;
	}

	static List<String> keywords(String question) {
		Set<String> out = new LinkedHashSet<>();
		for (String w : question.toLowerCase(Locale.forLanguageTag("tr")).split("[^\\p{L}\\p{N}_\\-]+")) {
			if (w.length() > 2 && !STOPWORDS.contains(w)) {
				out.add(w);
			}
			if (out.size() == 8) {
				break;
			}
		}
		return new ArrayList<>(out);
	}

	private PageText toPageText(Content c, int maxChars) {
		String text = StorageFormatConverter.toText(c.body() != null && c.body().storage() != null
				? c.body().storage().value()
				: "");
		boolean truncated = text.length() > maxChars;
		if (truncated) {
			text = text.substring(0, maxChars);
		}
		String url = pageUrl(c);
		return new PageText(c.id(), c.title(), c.space() == null ? null : c.space().key(),
				c.space() == null ? null : c.space().name(), url, text, truncated);
	}

	private String pageUrl(Content c) {
		return c.links() != null && c.links().webui() != null
				? props.baseUrl() + c.links().webui()
				: props.baseUrl() + "/pages/viewpage.action?pageId=" + c.id();
	}

	private <T> T getJson(String pathAndQuery, Class<T> type)
			throws IOException, InterruptedException {
		HttpRequest.Builder req = HttpRequest.newBuilder(URI.create(props.baseUrl() + pathAndQuery))
				.timeout(props.timeout())
				.header(HttpHeaders.ACCEPT, "application/json")
				.GET();
		String auth = authorization();
		if (auth != null) {
			req.header(HttpHeaders.AUTHORIZATION, auth);
		}
		return parseResponse(http.send(req.build(), HttpResponse.BodyHandlers.ofByteArray()), type);
	}

	private <T> T sendJson(String method, String path, Object body, Class<T> type)
			throws IOException, InterruptedException {
		HttpRequest.Builder req = HttpRequest.newBuilder(URI.create(props.baseUrl() + path))
				.timeout(props.timeout())
				.header(HttpHeaders.ACCEPT, "application/json")
				.header(HttpHeaders.CONTENT_TYPE, "application/json")
				.header("X-Atlassian-Token", "no-check")
				.method(method, HttpRequest.BodyPublishers.ofByteArray(json.writeValueAsBytes(body)));
		String auth = authorization();
		if (auth != null) {
			req.header(HttpHeaders.AUTHORIZATION, auth);
		}
		return parseResponse(http.send(req.build(), HttpResponse.BodyHandlers.ofByteArray()), type);
	}

	private <T> T parseResponse(HttpResponse<byte[]> res, Class<T> type) throws IOException {
		switch (res.statusCode()) {
			case 200 -> {
				return json.readValue(res.body(), type);
			}
			case 201 -> {
				return json.readValue(res.body(), type);
			}
			case 401 -> throw new ConfluenceException(401, hasToken()
					? "Confluence token'ı geçersiz veya süresi dolmuş."
					: "Confluence PAT tanımlı değil. Ayarlardan PAT girin.");
			case 403 -> throw new ConfluenceException(403, "Bu Confluence içeriğine erişim yetkiniz yok.");
			case 404 -> throw new ConfluenceException(404, "Confluence sayfası bulunamadı veya erişim yetkiniz yok.");
			case 409 -> throw new ConfluenceException(409, "Sayfa çakışması oluştu. Sayfayı yeniden yükleyin.");
			default -> throw new ConfluenceException(502, "Confluence HTTP " + res.statusCode() + " döndü.");
		}
	}

	private static String enc(String s) {
		return URLEncoder.encode(s, StandardCharsets.UTF_8);
	}

	private static String cqlEscape(String s) {
		return s.replace("\\", "\\\\").replace("\"", "\\\"");
	}
}
