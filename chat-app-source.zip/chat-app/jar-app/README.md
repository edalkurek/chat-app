# AI Sohbet Paneli — Masaüstü Paketi (Spring Boot + Gömülü JRE)

`../chat-app.html` dosyasını **değiştirmeden** Spring Boot ile `http://127.0.0.1:17860` adresinde sunar. Java kurulumu gerektirmeyen, taşınabilir bir Windows uygulaması olarak paketlenir.

## Kullanım (son kullanıcı)
1. `ChatApp-<sürüm>-win-x64.zip` dosyasını bir klasöre açın.
2. `ChatApp\ChatApp.exe` dosyasını çalıştırın. Panel varsayılan tarayıcıda açılır.
3. Kapatmak için sistem tepsisindeki ikona sağ tıklayıp **Çıkış**'ı seçin. Paneli yeniden açmak için ikona çift tıklayın veya **Paneli Aç**'ı seçin.

- Uygulama zaten açıksa `ChatApp.exe` yeni bir örnek başlatmaz, sadece paneli açar.
- Loglar `%USERPROFILE%\.chat-app\logs\chat-app.log` dosyasına yazılır.
- Port değiştirmek için `CHATAPP_PORT` ortam değişkeni kullanılır. Port değişirse tarayıcıdaki kayıtlı veriler (localStorage) görünmez.

## Confluence erişimi

1. Confluence'ta kişisel erişim belirteci (PAT) oluşturun.
2. Uygulamada **Yapılandırma ayarları → Confluence PAT** alanına yalnızca PAT değerini girip **Kaydet**'e basın. Bağlantı otomatik olarak test edilir; tekrar denemek için **Bağlantıyı test et** düğmesi vardır. Yeniden başlatma gerekmez.
3. Bilgi tabanı penceresinde Confluence bağlamını açarak soru sırasında sayfa bağlantılarını ve arama sonuçlarını kullanın. **Sayfa yönet** ile yeni sayfa oluşturabilir veya bağlantısını verdiğiniz mevcut sayfayı düzenleyebilirsiniz. Her iki işlemde de önce önizleme, sonra açıkça **Yayınla** gerekir.

Confluence adresi paket ayarıdır (`https://sdlc.yapikredi.com.tr/confluence`); son kullanıcı adres girmez. Farklı kurulumlarda yönetici `CONFLUENCE_BASE_URL` ile değiştirebilir. PAT sunucuda `%USERPROFILE%\.chat-app\confluence.pat` dosyasında tutulur; tarayıcı depolamasına veya dışa aktarılan ayarlara konmaz. Eski `CONFLUENCE_TOKEN`/`chatapp.confluence.token` ayarı yalnızca arayüzde kayıt yoksa yedek olarak okunur.

Arayüz Confluence'a uygulamanın yerel sunucusu üzerinden erişir. Genel `/api/confluence/**` proxy'si salt okunurdur; sayfa oluşturma ve düzenleme ayrı korumalı uçlardan yapılır. Şirket içi sertifikalar için Windows sertifika deposu kullanılır (`jdk.crypto.mscapi`). Kurum ağına/VPN'e bağlı değilseniz bağlantı testi başarısız olabilir.

## Geliştirici

| Komut | Açıklama |
|---|---|
| `.\mvnw.cmd spring-boot:run` | Geliştirme modunda çalıştırır |
| `.\mvnw.cmd package` | `target\chat-app.jar` üretir (`java -jar` ile çalışır, Java 17+ gerekir) |
| `.\build-package.ps1 [-SkipTests] [-OutputDirectory dist-updated]` | JAR → jlink JRE → jpackage → seçilen dağıtım klasörü (zip dahil) |

Gereksinim: JDK 17+ (`JAVA_HOME`). Maven kurulumu gerekmez, Maven Wrapper ile gelir.

### Yapı
- `pom.xml`: `chat-app.html` ve `../vendor/` bağımlılıkları derleme sırasında `static/` klasörüne filtrelenmeden kopyalanır. Arayüz çevrimdışı çalışır; Google fontları yüklenemezse sistem fontlarına geri döner.
- `ChatAppApplication`: giriş noktası, port çözümleme ve tek örnek kontrolü
- `WebConfig`: `/` adresini `chat-app.html`'e yönlendirir, tek örnek kontrolü için `/api/health` ucunu sunar
- `DesktopIntegration`: tepsi ikonu ve tarayıcıyı otomatik açma (`chatapp.desktop.*` ayarları)
- `packaging/icon.ico`: `.exe` ikonu

### Boyutlar (v1.0.0)
| Bileşen | Boyut |
|---|---|
| Fat JAR | 21,7 MB |
| Gömülü JRE (jlink) | 44,4 MB |
| Uygulama klasörü | 66,8 MB |
| Zip | 50,5 MB |
