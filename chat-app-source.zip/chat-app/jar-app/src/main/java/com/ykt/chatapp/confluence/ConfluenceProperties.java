package com.ykt.chatapp.confluence;

import java.time.Duration;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Confluence Data Center bağlantı ayarları.
 *
 * @param baseUrl Confluence kök adresi (context path dahil), örn. https://sdlc.yapikredi.com.tr/confluence
 * @param token   Eski kurulumlar için isteğe bağlı PAT; arayüzden kaydedilen PAT önceliklidir.
 * @param timeout Upstream istek zaman aşımı
 */
@ConfigurationProperties(prefix = "chatapp.confluence")
public record ConfluenceProperties(String baseUrl, String token, Duration timeout) {

	public ConfluenceProperties {
		if (baseUrl == null || baseUrl.isBlank()) {
			baseUrl = "https://sdlc.yapikredi.com.tr/confluence";
		}
		baseUrl = baseUrl.endsWith("/") ? baseUrl.substring(0, baseUrl.length() - 1) : baseUrl;
		token = token == null ? "" : token.trim();
		timeout = timeout == null ? Duration.ofSeconds(30) : timeout;
	}

	public boolean hasToken() {
		return !token.isEmpty();
	}
}
