package com.ykt.chatapp.confluence;

import java.security.KeyStore;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * JDK'nın cacerts deposuna ek olarak Windows "Güvenilen Kök Sertifika" deposuna da güvenen SSLContext.
 * <p>
 * Şirket içi sunucular (sdlc.yapikredi.com.tr gibi) genellikle kurumsal bir CA ile imzalanır; bu CA
 * Windows'a Group Policy ile yüklüdür ama gömülü JRE'nin cacerts dosyasında yoktur.
 */
final class CorporateTrust {

	private static final Logger log = LoggerFactory.getLogger(CorporateTrust.class);

	private CorporateTrust() {
	}

	static SSLContext sslContext() {
		try {
			List<X509TrustManager> managers = new ArrayList<>();
			managers.add(trustManager(null)); // JDK cacerts
			if (System.getProperty("os.name", "").toLowerCase().contains("win")) {
				try {
					KeyStore windowsRoot = KeyStore.getInstance("Windows-ROOT");
					windowsRoot.load(null, null);
					managers.add(trustManager(windowsRoot));
				} catch (Exception e) {
					log.warn("Windows sertifika deposu okunamadı, yalnızca JDK cacerts kullanılacak: {}", e.getMessage());
				}
			}
			SSLContext ctx = SSLContext.getInstance("TLS");
			ctx.init(null, new TrustManager[] { new CompositeTrustManager(managers) }, null);
			return ctx;
		} catch (Exception e) {
			throw new IllegalStateException("SSLContext oluşturulamadı", e);
		}
	}

	private static X509TrustManager trustManager(KeyStore store) throws Exception {
		TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
		tmf.init(store);
		for (TrustManager tm : tmf.getTrustManagers()) {
			if (tm instanceof X509TrustManager x509) {
				return x509;
			}
		}
		throw new IllegalStateException("X509TrustManager bulunamadı");
	}

	/** Herhangi bir alt yönetici zinciri doğrularsa kabul eder. */
	private record CompositeTrustManager(List<X509TrustManager> delegates) implements X509TrustManager {

		@Override
		public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
			check(chain, authType, true);
		}

		@Override
		public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
			check(chain, authType, false);
		}

		private void check(X509Certificate[] chain, String authType, boolean client) throws CertificateException {
			CertificateException last = null;
			for (X509TrustManager tm : delegates) {
				try {
					if (client) {
						tm.checkClientTrusted(chain, authType);
					} else {
						tm.checkServerTrusted(chain, authType);
					}
					return;
				} catch (CertificateException e) {
					last = e;
				}
			}
			throw last != null ? last : new CertificateException("Güvenilir sertifika deposu yok");
		}

		@Override
		public X509Certificate[] getAcceptedIssuers() {
			return delegates.stream().flatMap(tm -> java.util.Arrays.stream(tm.getAcceptedIssuers()))
					.toArray(X509Certificate[]::new);
		}
	}
}
