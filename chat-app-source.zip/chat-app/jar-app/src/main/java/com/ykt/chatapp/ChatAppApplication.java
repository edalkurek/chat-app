package com.ykt.chatapp;

import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;

import javax.swing.JOptionPane;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;

/**
 * Yapı Kredi Teknoloji — AI Sohbet Paneli masaüstü başlatıcısı.
 * <p>
 * chat-app.html dosyasını değiştirmeden 127.0.0.1 üzerinde sunar.
 * Aynı anda yalnızca bir örnek çalışır; ikinci açılışta mevcut panel tarayıcıda açılır.
 */
@SpringBootApplication
@ConfigurationPropertiesScan
public class ChatAppApplication {

	static final int DEFAULT_PORT = 17860;
	static final String HEALTH_MARKER = "chat-app";

	public static void main(String[] args) {
		int port = resolvePort(args);

		if (!isPortFree(port)) {
			if (isChatAppRunning(port)) {
				// Uygulama zaten açık: yalnızca paneli göster ve çık.
				BrowserLauncher.open(appUrl(port));
				return;
			}
			showError("Port " + port + " başka bir uygulama tarafından kullanılıyor.\n"
					+ "Farklı bir port için CHATAPP_PORT ortam değişkenini ayarlayın.");
			System.exit(1);
		}

		new SpringApplicationBuilder(ChatAppApplication.class)
				.headless(false) // Sistem tepsisi ve Desktop.browse için gerekli
				.run(args);
	}

	static String appUrl(int port) {
		return "http://127.0.0.1:" + port + "/";
	}

	/** Öncelik: --server.port=, -Dserver.port, CHATAPP_PORT, varsayılan. */
	static int resolvePort(String[] args) {
		String value = null;
		for (String arg : args) {
			if (arg.startsWith("--server.port=")) {
				value = arg.substring("--server.port=".length());
			}
		}
		if (value == null) value = System.getProperty("server.port");
		if (value == null) value = System.getenv("CHATAPP_PORT");
		try {
			return value == null ? DEFAULT_PORT : Integer.parseInt(value.trim());
		} catch (NumberFormatException e) {
			return DEFAULT_PORT;
		}
	}

	static boolean isPortFree(int port) {
		try (ServerSocket socket = new ServerSocket(port, 1, InetAddress.getLoopbackAddress())) {
			return true;
		} catch (IOException e) {
			return false;
		}
	}

	static boolean isChatAppRunning(int port) {
		try {
			HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(2)).build();
			HttpRequest request = HttpRequest.newBuilder(URI.create(appUrl(port) + "api/health"))
					.timeout(Duration.ofSeconds(2)).GET().build();
			HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
			return response.statusCode() == 200 && response.body().contains(HEALTH_MARKER);
		} catch (Exception e) {
			return false;
		}
	}

	private static void showError(String message) {
		try {
			JOptionPane.showMessageDialog(null, message, "AI Sohbet Paneli", JOptionPane.ERROR_MESSAGE);
		} catch (Throwable ignored) {
			System.err.println(message);
		}
	}
}
