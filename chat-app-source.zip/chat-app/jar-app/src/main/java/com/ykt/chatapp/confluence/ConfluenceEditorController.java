package com.ykt.chatapp.confluence;

import java.io.IOException;
import java.net.ConnectException;
import java.net.UnknownHostException;
import java.net.http.HttpTimeoutException;
import java.util.Map;

import javax.net.ssl.SSLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.CacheControl;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jakarta.servlet.http.HttpServletRequest;

/** PAT ayarlama, gerçek bağlantı testi ve onaylı sayfa yayınlama uçları. */
@RestController
class ConfluenceEditorController {

	private static final Logger log = LoggerFactory.getLogger(ConfluenceEditorController.class);

	private final ConfluenceClient confluence;
	private final ConfluenceTokenStore tokens;

	ConfluenceEditorController(ConfluenceClient confluence, ConfluenceTokenStore tokens) {
		this.confluence = confluence;
		this.tokens = tokens;
	}

	record TokenInput(String pat) {
		@Override
		public String toString() {
			return "TokenInput[pat=<redacted>]";
		}
	}

	record CreatePageInput(String spaceKey, String title, String text) {
		@Override
		public String toString() {
			return "CreatePageInput[content=<redacted>]";
		}
	}

	record UpdatePageInput(String title, String storage, int version) {
		@Override
		public String toString() {
			return "UpdatePageInput[content=<redacted>]";
		}
	}

	@PutMapping("/api/confluence-token")
	ResponseEntity<?> saveToken(@RequestBody TokenInput input, HttpServletRequest request) {
		return handle(request, true, () -> {
			tokens.save(input.pat());
			return Map.of("tokenConfigured", true);
		});
	}

	@DeleteMapping("/api/confluence-token")
	ResponseEntity<?> clearToken(HttpServletRequest request) {
		return handle(request, true, () -> {
			tokens.clear();
			return Map.of("tokenConfigured", false);
		});
	}

	@GetMapping("/api/confluence-connection")
	ResponseEntity<?> connection(HttpServletRequest request) {
		return handle(request, false, () -> {
			if (!tokens.configured()) {
				throw new ConfluenceClient.ConfluenceException(401, "Önce Confluence PAT girin.");
			}
			ConfluenceClient.CurrentUser user = confluence.currentUser();
			String name = user.displayName() != null ? user.displayName()
					: user.username() != null ? user.username() : "Confluence kullanıcısı";
			return Map.of("connected", true, "user", name);
		});
	}

	@GetMapping("/api/confluence-editor/page")
	ResponseEntity<?> page(@RequestParam String url, HttpServletRequest request) {
		return handle(request, false, () -> confluence.fetchEditablePage(url));
	}

	@PostMapping("/api/confluence-editor/pages")
	ResponseEntity<?> create(@RequestBody CreatePageInput input, HttpServletRequest request) {
		return handle(request, true, () -> confluence.createPage(input.spaceKey(), input.title(), input.text()));
	}

	@PutMapping("/api/confluence-editor/pages/{id}")
	ResponseEntity<?> update(@PathVariable String id, @RequestBody UpdatePageInput input,
			HttpServletRequest request) {
		return handle(request, true,
				() -> confluence.updatePage(id, input.title(), input.storage(), input.version()));
	}

	private interface Call {
		Object run() throws IOException, InterruptedException;
	}

	private ResponseEntity<?> handle(HttpServletRequest request, boolean mutation, Call call) {
		String rejection = mutation ? LocalCallerGuard.rejectMutation(request) : LocalCallerGuard.reject(request);
		if (rejection != null) {
			return error(403, rejection);
		}
		try {
			return ResponseEntity.ok().cacheControl(CacheControl.noStore()).body(call.run());
		} catch (ConfluenceClient.ConfluenceException e) {
			return error(e.status, e.getMessage());
		} catch (IllegalArgumentException e) {
			return error(400, e.getMessage());
		} catch (HttpTimeoutException e) {
			return error(504, "Confluence zaman aşımına uğradı.");
		} catch (SSLException e) {
			log.warn("Confluence TLS hatası", e);
			return error(502, "Confluence sertifikası doğrulanamadı.");
		} catch (ConnectException | UnknownHostException e) {
			return error(502, "Confluence'a ulaşılamadı. Kurum ağına/VPN'e bağlanın.");
		} catch (IOException e) {
			log.warn("Confluence isteği başarısız", e);
			return error(502, "Confluence isteği başarısız. Bağlantıyı ve kullanıcı izinlerini kontrol edin.");
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
			return error(503, "İstek iptal edildi.");
		}
	}

	private static ResponseEntity<Map<String, String>> error(int status, String message) {
		return ResponseEntity.status(status).cacheControl(CacheControl.noStore()).body(Map.of("error", message));
	}
}
