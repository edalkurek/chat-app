# 🎯 Yapı Kredi Teknoloji — AI Sohbet Paneli
## Kapsamlı Proje Sunum İçeriği ve Konuşmacı Rehberi

Bu doküman, **AI Sohbet Paneli (Yapı Kredi Teknoloji)** projesinin yönetici, teknik kurul veya ekiplere sunulması için slayt slayt hazırlanmış eksiksiz sunum içeriğini ve konuşmacı notlarını içerir.

---

## 📋 Sunum Genel Akışı (Slayt Planı)

| Slayt No | Başlık | Odak Noktası |
| :---: | :--- | :--- |
| **01** | **Kapak & Giriş** | Proje vizyonu, kurumsal kimlik |
| **02** | **Problem & Fırsat** | Kurumsal AI etkileşimindeki darboğazlar |
| **03** | **Çözüm & Temel Felsefe** | Tek HTML, sıfır sunucu bağımlılığı, Self-Cloning |
| **04** | **Teknoloji Mimarisi (Tech Stack)** | İstemci tabanlı mimari ve kullanılan teknolojiler |
| **05** | **Derinlemesine RAG Motoru** | Tarayıcıda Hibrit Arama (Vektör + BM25 + Türkçe Stemming) |
| **06** | **Gelişmiş Doküman Analitiği** | PDF, Excel, Word ve CSV doğrudan istemcide işleme |
| **07** | **Görselleştirme & Artifacts** | Mermaid.js, Chart.js ve izole Artifact Canvas |
| **08** | **Üretkenlik & Etkileşim Araçları** | Slash komutları, Sohbet Çatallama, Prompt Şablonları, Ses |
| **09** | **Dışa Aktarma & Raporlama** | Gerçek jsPDF motoru, Ekran Alıntısı, JSON senkronizasyon |
| **10** | **Güvenlik & Kurumsal Gizlilik** | Sıfır veri sızıntısı, DOMPurify sanitizasyon, yerel veri |
| **11** | **Canlı Demo Senaryosu** | Adım adım canlı demonstrasyon akışı |
| **12** | **Gelecek Yol Haritası & Kapanış** | Faz 2 hedefleri, Q&A ve Teşekkür |

---

---

##  слайд 1: Kapak & Giriş

### 🖼️ Slayt Başlığı & Alt Başlık
* **Başlık:** Yapı Kredi Teknoloji — AI Sohbet Paneli
* **Alt Başlık:** Kurumsal İş Akışları İçin Hafif, Güvenli ve Zengin Yetenekli İstemci Tabanlı Yapay Zeka Arayüzü
* **Etiketler:** `#GenAI` `#RAG` `#SingleFileApp` `#KurumsalTeknoloji`

### 📌 Slayt İçeriği (Görsel ve Maddeler)
* 🚀 **Kurumsal Seviye AI Deneyimi:** LLM bağımsız, esnek ve modüler bağlantı.
* 📦 **Sıfır Kurulum (Zero-Dependency):** Tek bir dosya ile anında kullanıma hazır.
* 🧠 **Dahili İstemci RAG Motoru:** Tarayıcıda koşan vektörel hafıza.
* 🎨 **Modern Kurumsal Kimlik:** Yapı Kredi lacivert/mavi paleti, karanlık/aydınlık tema.

### 🎙️ Konuşmacı Notları (Ne Söylenecek?)
> *"Saygıdeğer çalışma arkadaşlarım ve yöneticilerim, bugün sizlere Yapı Kredi Teknoloji ekosisteminde yapay zeka modelleriyle çalışma biçimimizi kökten kolaylaştıran **AI Sohbet Paneli** projemizi sunmaktan mutluluk duyuyorum.*  
> *Günümüzde kurumların en büyük ihtiyacı, yapay zekaya hızla erişebilmek, kurum verilerini dış ortama sızdırmadan analiz edebilmek ve karmaşık kurulumlarla vakit kaybetmemektir. Bu proje, tam da bu ihtiyaca yanıt veren yenilikçi bir çözüm olarak doğdu."*

---

##  слайд 2: Problem Tanımı ve Kurumsal İhtiyaçlar

### 🖼️ Slayt Başlığı & Alt Başlık
* **Başlık:** Kurumsal Yapay Zeka Kullanımındaki Zorluklar
* **Alt Başlık:** Mevcut çözümler neden hantal ve güvenlik endişesi yaratıyor?

### 📌 Slayt İçeriği (Görsel ve Maddeler)
* 🛑 **Ağır Kurulum & Altyapı Maliyetleri:**
  * Node.js, Python, Docker, backend sunucuları ve karmaşık deploy süreçleri.
* 🛑 **Veri Güvenliği ve Uyumluluk Endişeleri:**
  * Dokümanların üçüncü parti sunuculara veya bilinmeyen cloud servislerine yüklenme riski.
* 🛑 **Zayıf Görselleştirme & Yetersiz Çıktı:**
  * Standart sohbet kutularının sadece düz metin vermesi; tablo, şema ve grafik üretememesi.
* 🛑 **Model Bağımlılığı (Vendor Lock-in):**
  * Tek bir LLM sağlayıcısına mecbur kalma, API değişikliklerine hızlı adapte olamama.

### 🎙️ Konuşmacı Notları (Ne Söylenecek?)
> *"Piyasadaki birçok sohbet arayüzünü incelediğimizde iki temel problem görüyoruz: Ya devasa backend sunucuları, veritabanları ve microservisler kurmanız gerekiyor; ya da verilerinizi üçüncü taraf sistemlere emanet etmek zorunda kalıyorsunuz. Ayrıca bankacılık ve finans dünyasında sadece düz metin yanıtlar yetersiz kalıyor; akış şemalarına, dinamik grafiklere ve kurumsal raporlara ihtiyacımız var. Biz bu zorlukları avantaja dönüştürecek radikal bir mimari tercih yaptık."*

---

##  слайд 3: Çözüm & Temel Felsefe

### 🖼️ Slayt Başlığı & Alt Başlık
* **Başlık:** Radikal Sadakat: "Single-File" İstemci Mimarisi
* **Alt Başlık:** Sunucu yok, kurulum yok, tam kontrol kullanıcıda!

### 📌 Slayt İçeriği (Görsel ve Maddeler)
* ⚡ **Tek Dosya Mucizesi (`chat-app.html`):**
  * Tüm CSS, JS motoru, modal yapıları ve arayüz tek bir HTML dosyasında toplanmıştır.
  * Çift tıkla tarayıcıda açılır; sunucu kurmaya gerek yoktur.
* 🧬 **Self-Cloning Mekanizması:**
  * Kullanıcı arayüzde API uç noktasını, modelleri, tema rengini ve prompt şablonlarını ayarlar.
  * "Projeyi Klonla/İndir" butonuna bastığında, sayfa kendi kaynak kodundaki yapılandırma bloğunu regex ile güncelleyip kendine yeten yeni bir `.html` dosyası olarak bilgisayara indirir!
* 🔒 **Local-First & Offline Dayanıklılık:**
  * Tüm sohbet geçmişi ve dokümanlar tarayıcının `IndexedDB` ve `localStorage` alanında şifreli/güvenli tutulur.

### 🎙️ Konuşmacı Notları (Ne Söylenecek?)
> *"Projemizin en çarpıcı özelliği mimari felsefesidir: **Single-File Application**. Hiçbir backend gerektirmeden, sadece tarayıcı üzerinde çalışır.*  
> *Üstelik geliştirdiğimiz **Self-Cloning** teknolojisi sayesinde, bir departman kendi özel sistem prompt'unu ve kurum içi API ayarlarını yapıp 'İndir' dediğinde, tüm o ayarları kendi içine gömmüş bağımsız yeni bir HTML dosyası üretilir. Bu dosya e-posta veya Teams üzerinden ekibe dağıtılabilir; alan kişi tıkladığı anda aynı ayarlarla çalışmaya başlar."*

---

##  слайд 4: Teknoloji Mimarisi & Bileşenler

### 🖼️ Slayt Başlığı & Alt Başlık
* **Başlık:** Güçlü Kütüphane Ekosistemi & Entegrasyon Katmanı
* **Alt Başlık:** Modern web teknolojileriyle harmanlanmış yüksek performanslı arayüz

### 📌 Slayt İçeriği (Görsel ve Maddeler)
```
┌─────────────────────────────────────────────────────────────┐
│                 KULLANICI ARAYÜZÜ (UI/UX)                   │
│   Tailwind CSS (Derlenmiş) | Plus Jakarta Sans & JetBrains  │
├──────────────────────────────┬──────────────────────────────┤
│       DOKÜMAN & VERİ         │         GÖRSELLEŞTİRME       │
│  • PDF.js (Sayfa ayrıştırma) │  • Mermaid.js (Akış şeması)  │
│  • Mammoth.js (Word .docx)   │  • Chart.js (Grafikler)      │
│  • SheetJS (Excel .xlsx/.csv)│  • Highlight.js (Kod renkl.) │
├──────────────────────────────┼──────────────────────────────┤
│         RAG MOTORU           │      DIŞA AKTARMA & SES      │
│  • IndexedDB (Yerel Vektör)  │  • jsPDF & AutoTable (PDF)   │
│  • Kosinüs Benzerliği        │  • html2canvas (Ekran alıntı)│
│  • BM25 + Türkçe Kök Bulucu  │  • Web Speech API (Sesle yaz)│
└──────────────────────────────┴──────────────────────────────┘
```

### 🎙️ Konuşmacı Notları (Ne Söylenecek?)
> *"Arayüzümüzde Tailwind CSS'in optimize edilmiş hafif stil motorunu, tipografide ise kurumsal ciddiyeti temsil eden Plus Jakarta Sans ve JetBrains Mono'yu kullandık. Doküman okuma tarafında PDF.js, Mammoth ve SheetJS; görselleştirme tarafında ise Mermaid ve Chart.js yer alıyor. Dışa aktarmada tarayıcının 'Yazdır' penceresine muhtaç kalmadan doğrudan vektörel PDF oluşturan jsPDF motorumuz var."*

---

##  слайд 5: Tarayıcıda Çalışan RAG (Retrieval-Augmented Generation)

### 🖼️ Slayt Başlığı & Alt Başlık
* **Başlık:** Tarayıcı İçi Hibrit RAG Motoru
* **Alt Başlık:** Sunucusuz, sıfır maliyetli ve güvenli bilgi tabanı entegrasyonu

### 📌 Slayt İçeriği (Görsel ve Maddeler)
* 🧩 **Akıllı Parçalama (Chunking):**
  * 800 karakterlik hedef bloklar, 100 karakterlik bağlam örtüşmesi (overlap).
  * Paragraf ve cümle bütünlüğünü koruyan doğal metin bölme.
* 🔍 **Hibrit Arama Stratejisi (Hybrid Retrieval):**
  1. **Anlamsal Arama:** Vektör embedding üretimi ve Kosinüs Benzerliği (Eşik: `0.35`).
  2. **Anahtar Kelime Araması:** BM25 algoritması + Türkçe Harf Duyarlılığı + 4 karakterlik Kök Kırpma (Stemming).
* 🛡️ **Hata Toleransı (Graceful Degradation):**
  * Embedding modeli tanımlı değilse veya servis yanıt vermezse otomatik olarak BM25 anahtar kelime moduna düşer. Kullanıcının sohbeti asla kesintiye uğramaz!
* 🔄 **Model Değişiminde Otomatik Uyumluluk Kontrolü:**
  * Yeni embedding modeli seçildiğinde eski vektörleri tespit eder ve tek tıkla yeniden indeksler (`Reindex`).

### 🎙️ Konuşmacı Notları (Ne Söylenecek?)
> *"RAG konusu genellikle pahalı vektör veritabanları (Pinecone, Milvus, Chroma) ile anılır. Biz bu ezberi bozduk! Tamamen tarayıcının IndexedDB altyapısını kullanarak çalışan bir **Client-side RAG** motoru geliştirdik.*  
> *Sistem, yüklenen dosyaları anında parçalar, embedding API'sine gönderir ve tarayıcıda saklar. Kullanıcı soru sorduğunda, anlamsal kosinüs benzerliği ile BM25 anahtar kelime puanını harmanlayan hibrit bir arama yapar ve en doğru 8 pasajı bularak LLM'e bağlam olarak iletir. Üstelik Türkçe morfolojiyi destekleyen özel kök bulucumuz sayesinde bankacılık dokümanlarında yüksek isabet oranı sağlar."*

---

##  слайд 6: Çok Formatlı Doküman Analitiği

### 🖼️ Slayt Başlığı & Alt Başlık
* **Başlık:** İstemci Tarafında Doküman İşleme Gücü
* **Alt Başlık:** PDF, Excel, Word ve CSV formatlarında anında veri çıkarımı

### 📌 Slayt İçeriği (Görsel ve Maddeler)
* 📄 **PDF Analizi:**
  * `pdf.js` ile sayfalar taranır, ham metin ve tablo düzenleri yapısal metne dönüştürülür.
* 📊 **Excel & CSV Entegrasyonu:**
  * `SheetJS` ile finansal tablolar, bilanço ve veri setleri parse edilir; LLM'in en iyi anlayacağı temiz satır formatına indirgenir.
* 📝 **Word (.docx / .doc) Desteği:**
  * `mammoth.js` ile sözleşmeler, şartnameler ve kurumsal yazışmalar HTML/metin olarak süzülür.
* 💡 **Büyük Dosya Yönetimi:**
  * 10 MB'a kadar dosyaları doğrudan istemci belleğinde işleyerek bant genişliğinden tasarruf sağlar.

### 🎙️ Konuşmacı Notları (Ne Söylenecek?)
> *"Kullanıcılarımızın çoğu her gün onlarca PDF rapor, Excel tablosu ve Word dokümanıyla çalışıyor. Sistemimize sürükleyip bıraktıkları anda, dosya sunucuya gitmeden yerel olarak ayrıştırılıyor. Böylece hem işlem saniyeler içinde tamamlanıyor hem de hassas finansal verilerin istemci dışına kontrolsüz çıkması engelleniyor."*

---

##  слайд 7: Görselleştirme & Dinamik Çıktılar

### 🖼️ Slayt Başlığı & Alt Başlık
* **Başlık:** Sadece Metin Değil: Şemalar, Grafikler ve Kod Alanı
* **Alt Başlık:** Üretilen içeriği yaşayan, etkileşimli görsel nesnelere dönüştürme

### 📌 Slayt İçeriği (Görsel ve Maddeler)
* 📊 **Chart.js ile Canlı Grafikler:**
  * Modelden gelen veriler anında interaktif Bar, Line, Doughnut grafiklerine dönüşür.
* 🗺️ **Mermaid.js ile Süreç Modelleme:**
  * Mimari diyagramlar, iş akışları, durum makineleri ve sekans şemaları dinamik render edilir.
* 💻 **Gelişmiş Kod Blokları:**
  * JetBrains Mono fontu, sözdizimi renklendirme (Highlight.js), tek tıkla kopyalama ve çıktı önizleme.
* 🎴 **Artifact Canvas (Yan Panel Çalışma Alanı):**
  * Kod, HTML önizleme ve uzun teknik dokümanlar için Claude Artifacts benzeri bağımsız yan panel deneyimi.

### 🎙️ Konuşmacı Notları (Ne Söylenecek?)
> *"Finans ve teknoloji ekipleri için görsel anlatım hayati önem taşır. Yapay zekadan bir veri analizi istediğinizde, size sadece tablo değil, üzerine gelindiğinde detay gösteren bir Chart.js grafiği çizebiliyor. Ya da bir kredi onay sürecini sorduğunuzda, Mermaid.js ile kusursuz bir akış şeması sunuyor. Kod parçalarını ise Artifact Canvas adını verdiğimiz sağ panelde izole biçimde inceleyebiliyorsunuz."*

---

##  слайд 8: Üretkenlik & Gelişmiş Etkileşim Araçları

### 🖼️ Slayt Başlığı & Alt Başlık
* **Başlık:** Güçlü Kullanıcı Deneyimi (UX) & Hızlı Eylemler
* **Alt Başlık:** İş akışlarını hızlandıran modern üretkenlik yetenekleri

### 📌 Slayt İçeriği (Görsel ve Maddeler)
* ⚡ **Slash (/) Menüsü:**
  * `/ozet`, `/kod-analiz`, `/rag-ara`, `/grafik` gibi hazır hızlı komutlar.
* 🔀 **Sohbet Çatallama (Branching / Forking):**
  * Beğendiğiniz bir cevaptan itibaren konuşmayı yeni bir dala ayırıp alternatif senaryoları test edebilme.
* 📑 **Prompt Şablon Yönetimi:**
  * Departmanlara özel sistem rolleri (Analist, Geliştirici, Çevirmen, Hukuk Danışmanı) tanımlama ve saklama.
* 🎙️ **Sesle Yazma (Speech-to-Text):**
  * Web Speech API ile eller serbest prompt girişi.
* 🏷️ **Akıllı Yer İmleri & Etiketleme:**
  * Önemli yanıtları yıldızlama ve etiketlerle kategorize edebilme.

### 🎙️ Konuşmacı Notları (Ne Söylenecek?)
> *"Kullanıcı deneyimini kusursuz kılmak adına paneli modern etkileşim araçlarıyla donattık. Örneğin 'Sohbet Çatallama' sayesinde, uzun bir konuşmanın ortasından yeni bir dal açıp farklı bir parametreyle konuşmayı sürdürebiliyorsunuz. Slash menüsüyle uzun promptlar yazmaktan kurtuluyor, tek tuşla mikrofonu açıp sesinizle soru sorabiliyorsunuz."*

---

##  слайд 9: Raporlama, Dışa Aktarma & Yedekleme

### 🖼️ Slayt Başlığı & Alt Başlık
* **Başlık:** Verilerinizi Kurumsal Çıktıya Dönüştürün
* **Alt Başlık:** Tek tıkla resmi raporlar, PDF ve tam sistem yedeklemesi

### 📌 Slayt İçeriği (Görsel ve Maddeler)
* 📄 **Vektörel PDF Üretimi (jsPDF + AutoTable):**
  * Sayfa kesilme sorunlarını önleyen, başlıklı ve profesyonel sayfa numaralandırmalı PDF çıktısı.
* 📸 **Ekran Alıntısı (html2canvas):**
  * Sohbetin veya grafiklerin doğrudan PNG görseli olarak indirilmesi.
* 💾 **Veri İçe/Dışa Aktarma:**
  * Tüm sohbet geçmişini, ayarları ve bilgi tabanı indekslerini JSON formatında dışa aktarma ve başka bir cihaza kolayca taşıma.

### 🎙️ Konuşmacı Notları (Ne Söylenecek?)
> *"Sohbet bittiğinde üretilen bilginin arşivlenmesi gerekir. Çoğu araç tarayıcının Ctrl+P menüsünü açtırıp bozuk düzenli çıktılar verir. Biz ise doğrudan istemcide çalışan jsPDF kütüphanesiyle kurumsal başlıklı, logolu, sayfalara bölünmüş tertemiz PDF raporları üretiyoruz. Ayrıca tüm verilerinizi JSON olarak yedekleyip dilediğiniz zaman geri yükleyebilirsiniz."*

---

## слайд 10: Kurumsal Güvenlik & Gizlilik

### 🖼️ Slayt Başlığı & Alt Başlık
* **Başlık:** Güvenlik Öncelikli Mimari: Veriniz Sizde Kalır
* **Alt Başlık:** Finansal regülasyonlara ve kurumsal KVKK/GDPR standartlarına tam uyum

### 📌 Slayt İçeriği (Görsel ve Maddeler)
* 🔒 **Sıfır İstemci Dışı Sızıntı:**
  * Dosyalar ve veri tabanı sadece kullanıcının bilgisayarındaki IndexedDB'de yaşar.
* 🛡️ **DOMPurify ile XSS Koruması:**
  * Yapay zekadan dönen veya kullanıcı tarafından girilen tüm Markdown ve HTML içerikler zararlı script enjeksiyonuna karşı anında sanitize edilir.
* 🔑 **Güvenli Kimlik Yönetimi:**
  * API anahtarları harici sunucuya iletilmez, yalnızca LLM uç noktasına doğrudan şifreli `Authorization` başlığı ile gider.
* 👁️ **Self-Cloning'de Hassas Veri Arındırma:**
  * Proje klonlanırken istenirse API anahtarları temizlenerek dağıtım kopyası oluşturulabilir.

### 🎙️ Konuşmacı Notları (Ne Söylenecek?)
> *"Bir finans kuruluşunda en kritik unsur güvenliktir. Bu panelde hiçbir ara sunucu bulunmadığı için, yüklediğiniz belgeler veya yazdığınız promptlar bizim tarafımızdan kaydedilmez veya dinlenemez. Tarayıcı seviyesinde DOMPurify kütüphanesiyle XSS açıklarına karşı en üst düzey filtreleme uygulanmaktadır."*

---

## слайд 11: Canlı Demo Senaryosu (Canlı Akış Planı)

### 🖼️ Slayt Başlığı & Alt Başlık
* **Başlık:** Canlı Uygulama Demosu
* **Alt Başlık:** 3 dakikada uçtan uca kullanım senaryosu

### 📌 Canlı Demo Adımları (Sunum Sırasında Yapılacaklar):
1. **Adım 1 - Arayüz Tanıtımı & Tema Değişimi:**
   * Açık/Koyu tema geçişi ve kurumsal renk uyumu.
2. **Adım 2 - Doküman Yükleme & RAG:**
   * Bilgi Tabanı modalına bir PDF/Excel dosyası sürüklenir.
   * Parçalama ve indekslemenin saniyeler içinde tamamlandığı gösterilir.
3. **Adım 3 - Akıllı Soru & Kaynak Gösterimi:**
   * Dokümanla ilgili soru sorulur; sistemin bağlamı bulup yanıtladığı izlenir.
4. **Adım 4 - Görselleştirme:**
   * Yapay zekadan bir süreç şeması (Mermaid) ve performans grafiği (Chart.js) üretmesi istenir.
5. **Adım 5 - Çıktı Alma:**
   * Üretilen analiz tek tıkla profesyonel PDF olarak dışa aktarılır.

### 🎙️ Konuşmacı Notları (Ne Söylenecek?)
> *"Şimdi izninizle anlattıklarımızı canlı sistem üzerinde birlikte deneyimleyelim. Karşınızda tek bir HTML dosyası olarak çalışan uygulamamız..."*

---

## слайд 12: Gelecek Yol Haritası & Kapanış

### 🖼️ Slayt Başlığı & Alt Başlık
* **Başlık:** Yol Haritası & Soru - Cevap
* **Alt Başlık:** Gelecek vizyonu ve sürekli gelişim

### 📌 Slayt İçeriği (Görsel ve Maddeler)
* 🗺️ **Faz 2 Yol Haritası:**
  * WebGPU tabanlı istemci içi yerel küçük modeller (WebLLM - Çevrimdışı AI).
  * Çoklu doküman karşılaştırma ve çapraz RAG sorguları.
  * Kurumsal SSO / OAuth2 entegrasyon şablonları.
* 🤝 **Özet & Değer:**
  * Kurulumsuz, güvenli, hafif ve zengin yetenekli kurumsal AI standardı.
* 💬 **Soru & Cevap (Q&A):**
  * Görüşleriniz ve sorularınız için teşekkür ederiz.

### 🎙️ Konuşmacı Notları (Ne Söylenecek?)
> *"AI Sohbet Paneli, Yapı Kredi Teknoloji'nin inovasyon ve hız vizyonunu sahaya yansıtan somut bir örnektir. Dinlediğiniz ve katkılarınız için teşekkür ederim. Şimdi sorularınızı almaktan memnuniyet duyarım."*

---

## 💡 Sunum İpuçları ve Başarı Taktikleri

1. **Önceden Hazırlık:** Demo yapacaksanız, `chat-app.html` dosyasını tarayıcınızda hazır bir sekmede açık tutun ve test bir PDF dosyasını masaüstünüzde bulundurun.
2. **Vurgu Noktası:** "Sıfır Kurulum" ve "Tarayıcıda Çalışan RAG" özelliklerini sunumun yıldızları olarak öne çıkarın; kurumsal dinleyicilerin en çok ilgisini çeken noktalar bunlardır.
3. **Zaman Yönetimi:** Toplam 15 dakikalık bir oturumda 8-10 dakika slayt anlatımı, 3-4 dakika canlı demo ve 3 dakika soru-cevap en ideal dengedir.
