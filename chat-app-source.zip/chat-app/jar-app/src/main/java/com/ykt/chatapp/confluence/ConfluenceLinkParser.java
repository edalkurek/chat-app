package com.ykt.chatapp.confluence;

import java.net.URI;
import java.net.URLDecoder;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Confluence Data Center sayfa linklerini çözümler. Desteklenen biçimler:
 * <ul>
 * <li>{@code /pages/viewpage.action?pageId=123}</li>
 * <li>{@code /spaces/KEY/pages/123/Baslik} (DC 8+)</li>
 * <li>{@code /display/KEY/Sayfa+Basligi}</li>
 * <li>{@code /x/AbCd} (kısa link)</li>
 * </ul>
 */
final class ConfluenceLinkParser {

	/** Sayfaya id ile veya alan + başlık ile ulaşılır. */
	record PageRef(String pageId, String spaceKey, String title) {
		static PageRef ofId(String id) {
			return new PageRef(id, null, null);
		}
	}

	private static final Pattern PAGE_ID_PARAM = Pattern.compile("(?:^|&)pageId=(\\d+)");
	private static final Pattern SPACES_PAGES = Pattern.compile("/spaces/[^/]+/pages/(\\d+)");
	private static final Pattern DISPLAY = Pattern.compile("/display/([^/]+)/([^/?#]+)");
	private static final Pattern TINY = Pattern.compile("/x/([A-Za-z0-9_\\-]+)");

	private ConfluenceLinkParser() {
	}

	/**
	 * @param link    kullanıcının yapıştırdığı link
	 * @param baseUrl yapılandırılmış Confluence kök adresi; link aynı sunucuya ait olmalı
	 * @return çözümlenemezse {@code null}
	 */
	static PageRef parse(String link, String baseUrl) {
		URI uri;
		URI base;
		try {
			uri = URI.create(link.trim());
			base = URI.create(baseUrl);
		} catch (IllegalArgumentException e) {
			return null;
		}
		if (uri.getHost() == null || !uri.getHost().equalsIgnoreCase(base.getHost())) {
			return null;
		}
		String path = uri.getRawPath() == null ? "" : uri.getRawPath();
		String basePath = base.getRawPath() == null ? "" : base.getRawPath();
		if (!basePath.isEmpty() && path.startsWith(basePath)) {
			path = path.substring(basePath.length());
		}

		if (uri.getRawQuery() != null) {
			Matcher m = PAGE_ID_PARAM.matcher(uri.getRawQuery());
			if (m.find()) {
				return PageRef.ofId(m.group(1));
			}
		}
		Matcher m = SPACES_PAGES.matcher(path);
		if (m.find()) {
			return PageRef.ofId(m.group(1));
		}
		m = DISPLAY.matcher(path);
		if (m.find()) {
			return new PageRef(null, decode(m.group(1)), decode(m.group(2)));
		}
		m = TINY.matcher(path);
		if (m.find()) {
			Long id = decodeTinyLink(m.group(1));
			return id == null ? null : PageRef.ofId(String.valueOf(id));
		}
		return null;
	}

	/** Confluence kısa linkleri, sayfa id'sinin little-endian baytlarının URL-güvenli base64 halidir. */
	static Long decodeTinyLink(String code) {
		try {
			StringBuilder b64 = new StringBuilder(code.replace('-', '/').replace('_', '+'));
			while (b64.length() % 4 != 0) {
				b64.append('A');
			}
			byte[] bytes = Base64.getDecoder().decode(b64.toString());
			byte[] padded = new byte[8];
			System.arraycopy(bytes, 0, padded, 0, Math.min(8, bytes.length));
			long id = ByteBuffer.wrap(padded).order(ByteOrder.LITTLE_ENDIAN).getLong();
			return id > 0 ? id : null;
		} catch (IllegalArgumentException e) {
			return null;
		}
	}

	private static String decode(String s) {
		return URLDecoder.decode(s, StandardCharsets.UTF_8);
	}
}
