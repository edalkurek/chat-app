package com.ykt.chatapp.confluence;

import java.io.IOException;
import java.net.ConnectException;
import java.net.UnknownHostException;
import java.net.http.HttpTimeoutException;
import java.util.List;
import java.util.Map;

import javax.net.ssl.SSLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jakarta.servlet.http.HttpServletRequest;

/**
 * Sohbet arayüzü için üst düzey Confluence uçları:
 * <ul>
 * <li>{@code GET /api/confluence-page?url=...} — mesajdaki linkin içeriği</li>
 * <li>{@code GET /api/confluence-search?q=...&limit=5} — RAG için arama sonuçları (tam metin)</li>
 * </ul>
 */
@RestController
class ConfluenceContextController {

	private static final Logger log = LoggerFactory.getLogger(ConfluenceContextController.class);

	private final ConfluenceClient confluence;

	ConfluenceContextController(ConfluenceClient confluence) {
		this.confluence = confluence;
	}

	@GetMapping("/api/confluence-page")
	ResponseEntity<?> page(@RequestParam String url, HttpServletRequest request) {
		return handle(request, () -> confluence.fetchPageByLink(url));
	}

	@GetMapping("/api/confluence-search")
	ResponseEntity<?> search(@RequestParam String q, @RequestParam(defaultValue = "5") int limit,
			HttpServletRequest request) {
		int safeLimit = Math.max(1, Math.min(limit, 10));
		return handle(request, () -> Map.of("results",
				confluence.search(q, safeLimit)));
	}

	private interface Call {
		Object run() throws IOException, InterruptedException;
	}

	private ResponseEntity<?> handle(HttpServletRequest request, Call call) {
		String rejection = LocalCallerGuard.reject(request);
		if (rejection != null) {
			return error(403, rejection);
		}
		try {
			return ResponseEntity.ok(call.run());
		} catch (ConfluenceClient.ConfluenceException e) {
			return error(e.status, e.getMessage());
		} catch (HttpTimeoutException e) {
			return error(504, "Confluence zaman aşımına uğradı.");
		} catch (SSLException e) {
			log.warn("Confluence TLS hatası", e);
			return error(502, "Confluence sertifikası doğrulanamadı: " + e.getMessage());
		} catch (ConnectException | UnknownHostException e) {
			return error(502, "Confluence'a ulaşılamadı. Kurum ağına/VPN'e bağlı olduğunuzdan emin olun.");
		} catch (IOException e) {
			log.warn("Confluence isteği başarısız", e);
			return error(502, "Confluence isteği başarısız: " + e.getMessage());
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
			return error(503, "İstek iptal edildi.");
		} catch (RuntimeException e) {
			log.warn("Confluence yanıtı işlenemedi", e);
			return error(502, "Confluence yanıtı işlenemedi: " + e.getMessage());
		}
	}

	private static ResponseEntity<Map<String, String>> error(int status, String message) {
		return ResponseEntity.status(status).body(Map.of("error", message));
	}
}
