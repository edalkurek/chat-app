package com.ykt.chatapp;

import java.io.IOException;
import java.util.Map;

import org.springframework.core.io.ClassPathResource;
import org.springframework.http.CacheControl;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/** Kök adresinde güncel arayüzü ve tek-örnek kontrolü için sağlık ucunu sunar. */
@Configuration
@RestController
class WebConfig {

	private final byte[] html;

	WebConfig() throws IOException {
		try (var stream = new ClassPathResource("static/chat-app.html").getInputStream()) {
			html = stream.readAllBytes();
		}
	}

	@GetMapping(value = { "/", "/chat-app.html" }, produces = MediaType.TEXT_HTML_VALUE)
	ResponseEntity<byte[]> index() {
		return ResponseEntity.ok()
				.cacheControl(CacheControl.noStore())
				.contentType(MediaType.TEXT_HTML)
				.body(html);
	}

	@GetMapping("/api/health")
	Map<String, String> health() {
		return Map.of("app", ChatAppApplication.HEALTH_MARKER, "status", "UP");
	}
}
