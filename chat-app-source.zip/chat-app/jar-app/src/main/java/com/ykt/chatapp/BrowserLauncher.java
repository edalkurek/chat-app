package com.ykt.chatapp;

import java.awt.Desktop;
import java.net.URI;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Varsayılan tarayıcıda URL açar; AWT desteklenmezse Windows kabuğuna düşer. */
final class BrowserLauncher {

	private static final Logger log = LoggerFactory.getLogger(BrowserLauncher.class);

	private BrowserLauncher() {
	}

	static void open(String url) {
		try {
			if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.BROWSE)) {
				Desktop.getDesktop().browse(URI.create(url));
				return;
			}
		} catch (Exception e) {
			log.warn("Desktop.browse başarısız, alternatif yöntem denenecek: {}", e.getMessage());
		}
		try {
			String os = System.getProperty("os.name", "").toLowerCase();
			ProcessBuilder pb = os.contains("win")
					? new ProcessBuilder("rundll32", "url.dll,FileProtocolHandler", url)
					: os.contains("mac") ? new ProcessBuilder("open", url) : new ProcessBuilder("xdg-open", url);
			pb.start();
		} catch (Exception e) {
			log.error("Tarayıcı açılamadı. Adresi elle açın: {}", url, e);
		}
	}
}
